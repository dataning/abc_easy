"""
Valuation Backtesting Module

This module provides tools to backtest startup valuation methodologies:
- Approach 1: Trading Multiples (EV/Revenue)
- Approach 2: Bottom-Up Beta (CAPM + DCF)

Usage:
    from backtesting import BacktestRunner
    runner = BacktestRunner()
    results = runner.run_full_backtest()
"""

from .config import STARTUPS, VALUATION_PARAMS, PEER_SCENARIOS
from .data_fetcher import PeerDataFetcher
from .valuation_engine import ValuationEngine
from .backtest_runner import BacktestRunner
from .metrics import AccuracyMetrics
from .scenario_generator import ScenarioGenerator

__all__ = [
    'STARTUPS',
    'VALUATION_PARAMS',
    'PEER_SCENARIOS',
    'PeerDataFetcher',
    'ValuationEngine',
    'BacktestRunner',
    'AccuracyMetrics',
    'ScenarioGenerator'
]
