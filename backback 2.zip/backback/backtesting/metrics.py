"""
Accuracy Metrics for Valuation Backtesting

Calculates and categorizes valuation accuracy across approaches.
"""

from typing import Dict, List
import statistics


class AccuracyMetrics:
    """Calculate valuation accuracy metrics for backtesting."""

    # Gap category thresholds
    GAP_THRESHOLDS = {
        "aligned": 2.0,      # Within 2x = aligned with multiples
        "moderate": 5.0,     # 2-5x = moderate premium
        "significant": 10.0,  # 5-10x = significant premium
        "extreme": 20.0      # 10-20x = extreme premium
        # > 20x = outlier
    }

    # Cost of Equity reasonableness
    COE_RANGE = {
        "min_reasonable": 15.0,  # 15%
        "max_reasonable": 25.0,  # 25%
        "typical_low": 17.0,
        "typical_high": 20.0
    }

    @classmethod
    def undervaluation_gap(cls, implied: float, actual: float) -> float:
        """
        Calculate how many times actual exceeds implied valuation.

        Args:
            implied: Implied valuation from multiples
            actual: Actual deal valuation

        Returns:
            Gap multiplier (actual / implied)
        """
        if implied <= 0:
            return float('inf')
        return actual / implied

    @classmethod
    def gap_category(cls, gap: float) -> str:
        """
        Categorize the valuation gap.

        Args:
            gap: Undervaluation gap (actual / implied)

        Returns:
            Category string
        """
        if gap < cls.GAP_THRESHOLDS["aligned"]:
            return "aligned"
        elif gap < cls.GAP_THRESHOLDS["moderate"]:
            return "moderate"
        elif gap < cls.GAP_THRESHOLDS["significant"]:
            return "significant"
        elif gap < cls.GAP_THRESHOLDS["extreme"]:
            return "extreme"
        else:
            return "outlier"

    @classmethod
    def gap_color(cls, gap: float) -> str:
        """
        Get color code for gap visualization.

        Args:
            gap: Undervaluation gap

        Returns:
            CSS color string
        """
        category = cls.gap_category(gap)
        colors = {
            "aligned": "#10b981",    # Green
            "moderate": "#f59e0b",   # Yellow/Orange
            "significant": "#ef4444", # Red
            "extreme": "#dc2626",    # Dark Red
            "outlier": "#991b1b"     # Very Dark Red
        }
        return colors.get(category, "#6b7280")

    @classmethod
    def approach_1_accuracy_scores(cls, results: List[Dict]) -> Dict:
        """
        Calculate accuracy metrics for Trading Multiples approach.

        Lower gap = better accuracy (multiples match actual valuation).

        Args:
            results: List of backtest results

        Returns:
            Dictionary with accuracy metrics
        """
        gaps = []
        categories = {"aligned": 0, "moderate": 0, "significant": 0, "extreme": 0, "outlier": 0}

        for r in results:
            if "approach_1" in r and "gap" in r["approach_1"]:
                gap = r["approach_1"]["gap"]
                if gap > 0 and gap != float('inf'):
                    gaps.append(gap)
                    categories[cls.gap_category(gap)] += 1

        if not gaps:
            return {
                "count": 0,
                "mean_gap": 0,
                "median_gap": 0,
                "accuracy_score": 0
            }

        total = len(gaps)

        return {
            "count": total,

            # Central tendency
            "mean_gap": round(statistics.mean(gaps), 2),
            "median_gap": round(statistics.median(gaps), 2),
            "min_gap": round(min(gaps), 2),
            "max_gap": round(max(gaps), 2),

            # Dispersion
            "std_gap": round(statistics.stdev(gaps), 2) if len(gaps) > 1 else 0,

            # Category distribution
            "categories": categories,
            "pct_aligned": round(categories["aligned"] / total * 100, 1),
            "pct_within_5x": round((categories["aligned"] + categories["moderate"]) / total * 100, 1),

            # Accuracy score (inverse of median gap, capped)
            "accuracy_score": round(min(1 / statistics.median(gaps), 1.0) * 100, 1),

            # Interpretation
            "interpretation": cls._interpret_accuracy(statistics.median(gaps))
        }

    @classmethod
    def _interpret_accuracy(cls, median_gap: float) -> str:
        """Interpret accuracy based on median gap."""
        if median_gap < 2:
            return "High accuracy - multiples closely match actual valuations"
        elif median_gap < 5:
            return "Moderate accuracy - multiples somewhat undervalue"
        elif median_gap < 10:
            return "Low accuracy - multiples significantly undervalue"
        else:
            return "Poor accuracy - multiples grossly undervalue; different approach needed"

    @classmethod
    def approach_2_usefulness_scores(cls, results: List[Dict]) -> Dict:
        """
        Calculate usefulness metrics for Bottom-Up Beta approach.

        Approach 2 produces Cost of Equity, not a valuation.
        Score based on: reasonable range (15-25%), consistency.

        Args:
            results: List of backtest results

        Returns:
            Dictionary with usefulness metrics
        """
        coe_values = []

        for r in results:
            if "approach_2" in r and "cost_of_equity_pct" in r["approach_2"]:
                coe = r["approach_2"]["cost_of_equity_pct"]
                if coe > 0:
                    coe_values.append(coe)

        if not coe_values:
            return {
                "count": 0,
                "mean_coe": 0,
                "usefulness_score": 0
            }

        total = len(coe_values)
        mean_coe = statistics.mean(coe_values)
        std_coe = statistics.stdev(coe_values) if len(coe_values) > 1 else 0

        # Count how many are in reasonable range
        in_range = sum(1 for c in coe_values
                      if cls.COE_RANGE["min_reasonable"] <= c <= cls.COE_RANGE["max_reasonable"])

        # Usefulness score based on:
        # 1. What % are in reasonable range
        # 2. How consistent (low std) the results are
        range_score = in_range / total
        consistency_score = max(0, 1 - (std_coe / 5))  # Penalize high variance
        usefulness = (range_score * 0.7 + consistency_score * 0.3) * 100

        return {
            "count": total,

            # Central tendency
            "mean_coe": round(mean_coe, 2),
            "median_coe": round(statistics.median(coe_values), 2),
            "min_coe": round(min(coe_values), 2),
            "max_coe": round(max(coe_values), 2),

            # Dispersion
            "std_coe": round(std_coe, 2),

            # Reasonableness
            "pct_in_reasonable_range": round(in_range / total * 100, 1),
            "reasonable_range": f"{cls.COE_RANGE['min_reasonable']}-{cls.COE_RANGE['max_reasonable']}%",

            # Usefulness score
            "usefulness_score": round(usefulness, 1),

            # Interpretation
            "interpretation": cls._interpret_coe_usefulness(mean_coe, std_coe, in_range / total)
        }

    @classmethod
    def _interpret_coe_usefulness(cls, mean_coe: float, std_coe: float, pct_in_range: float) -> str:
        """Interpret Cost of Equity usefulness."""
        if pct_in_range > 0.8 and std_coe < 2:
            return "Highly useful - consistent, reasonable discount rates"
        elif pct_in_range > 0.5:
            return "Moderately useful - most results in reasonable range"
        elif mean_coe > cls.COE_RANGE["max_reasonable"]:
            return "Caution - high discount rates may overstate risk"
        else:
            return "Review peers - results outside expected range"

    @classmethod
    def compare_approaches(cls, results: List[Dict]) -> Dict:
        """
        Compare the two approaches across all results.

        Args:
            results: List of backtest results

        Returns:
            Comparison summary
        """
        approach_1_scores = cls.approach_1_accuracy_scores(results)
        approach_2_scores = cls.approach_2_usefulness_scores(results)

        # Determine winner
        # Approach 1 wins if median gap < 3 (multiples are useful)
        # Approach 2 wins if gap > 3 AND CoE is in reasonable range
        median_gap = approach_1_scores.get("median_gap", 10)
        coe_useful = approach_2_scores.get("pct_in_reasonable_range", 0) > 70

        if median_gap < 3:
            winner = "trading_multiples"
            reason = f"Median gap of {median_gap:.1f}x is low enough for multiples to be directionally useful"
        elif coe_useful:
            winner = "bottom_up_beta"
            reason = f"Median gap of {median_gap:.1f}x makes multiples unreliable; Bottom-Up Beta provides consistent framework"
        else:
            winner = "neither"
            reason = "Neither approach performs well - review comparable selection"

        return {
            "approach_1": approach_1_scores,
            "approach_2": approach_2_scores,
            "winner": winner,
            "winner_reason": reason,
            "recommendation": cls._generate_recommendation(median_gap, approach_2_scores)
        }

    @classmethod
    def _generate_recommendation(cls, median_gap: float, approach_2_scores: Dict) -> str:
        """Generate actionable recommendation."""
        mean_coe = approach_2_scores.get("mean_coe", 18)

        if median_gap < 2:
            return f"Use peer multiples directly. Results closely track actual valuations."
        elif median_gap < 5:
            return f"Use multiples as floor ({median_gap:.1f}x gap typical). Apply premium based on growth/strategic value."
        else:
            return f"Multiples undervalue by {median_gap:.1f}x on average. Use Bottom-Up Beta (CoE ~{mean_coe:.0f}%) for DCF to find ceiling."

    @classmethod
    def group_by_deal_type(cls, results: List[Dict]) -> Dict:
        """
        Group accuracy metrics by deal type.

        Args:
            results: List of backtest results

        Returns:
            Metrics grouped by deal type
        """
        by_type = {}

        for r in results:
            deal_type = r.get("startup_data", {}).get("deal_type", "unknown")
            if deal_type not in by_type:
                by_type[deal_type] = []
            by_type[deal_type].append(r)

        return {
            deal_type: {
                "count": len(type_results),
                "metrics": cls.compare_approaches(type_results)
            }
            for deal_type, type_results in by_type.items()
        }

    @classmethod
    def group_by_growth_rate(cls, results: List[Dict]) -> Dict:
        """
        Group accuracy metrics by growth rate buckets.

        Args:
            results: List of backtest results

        Returns:
            Metrics grouped by growth rate
        """
        buckets = {
            "high_growth": [],      # > 200%
            "strong_growth": [],    # 100-200%
            "moderate_growth": [],  # 50-100%
            "stable": []            # < 50%
        }

        for r in results:
            growth = r.get("startup_data", {}).get("growth_rate_pct", 0)
            if growth > 200:
                buckets["high_growth"].append(r)
            elif growth > 100:
                buckets["strong_growth"].append(r)
            elif growth > 50:
                buckets["moderate_growth"].append(r)
            else:
                buckets["stable"].append(r)

        return {
            bucket: {
                "count": len(bucket_results),
                "growth_range": cls._get_growth_range(bucket),
                "metrics": cls.compare_approaches(bucket_results) if bucket_results else None
            }
            for bucket, bucket_results in buckets.items()
        }

    @classmethod
    def _get_growth_range(cls, bucket: str) -> str:
        """Get growth range description for bucket."""
        ranges = {
            "high_growth": ">200%",
            "strong_growth": "100-200%",
            "moderate_growth": "50-100%",
            "stable": "<50%"
        }
        return ranges.get(bucket, "Unknown")

    @classmethod
    def sensitivity_summary(cls, sensitivity_results: List[Dict]) -> Dict:
        """
        Summarize sensitivity analysis results.

        Args:
            sensitivity_results: Results from testing different peer selections

        Returns:
            Summary of how sensitive valuations are to peer selection
        """
        if not sensitivity_results:
            return {"error": "No sensitivity data"}

        gaps = [r.get("approach_1", {}).get("gap", 0) for r in sensitivity_results]
        coes = [r.get("approach_2", {}).get("cost_of_equity_pct", 0) for r in sensitivity_results]

        valid_gaps = [g for g in gaps if g > 0 and g != float('inf')]
        valid_coes = [c for c in coes if c > 0]

        gap_range = max(valid_gaps) - min(valid_gaps) if valid_gaps else 0
        coe_range = max(valid_coes) - min(valid_coes) if valid_coes else 0

        return {
            "peer_variations_tested": len(sensitivity_results),

            # Gap sensitivity
            "gap_min": round(min(valid_gaps), 2) if valid_gaps else 0,
            "gap_max": round(max(valid_gaps), 2) if valid_gaps else 0,
            "gap_range": round(gap_range, 2),
            "gap_sensitivity": "high" if gap_range > 3 else "moderate" if gap_range > 1 else "low",

            # CoE sensitivity
            "coe_min": round(min(valid_coes), 2) if valid_coes else 0,
            "coe_max": round(max(valid_coes), 2) if valid_coes else 0,
            "coe_range": round(coe_range, 2),
            "coe_sensitivity": "high" if coe_range > 3 else "moderate" if coe_range > 1 else "low",

            # Interpretation
            "interpretation": cls._interpret_sensitivity(gap_range, coe_range)
        }

    @classmethod
    def _interpret_sensitivity(cls, gap_range: float, coe_range: float) -> str:
        """Interpret sensitivity analysis results."""
        if gap_range > 5 or coe_range > 4:
            return "High sensitivity - peer selection significantly impacts results. Choose comparables carefully."
        elif gap_range > 2 or coe_range > 2:
            return "Moderate sensitivity - results vary with peer selection but within reasonable bounds."
        else:
            return "Low sensitivity - results are robust across different peer selections."
