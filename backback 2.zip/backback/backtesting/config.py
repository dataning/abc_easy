"""
Configuration for Valuation Backtesting

Contains:
- Startup definitions (8 AI companies)
- Peer group mappings
- Valuation parameters (CAPM inputs)
- Peer selection scenarios
"""

from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = DATA_DIR / "peer_cache"

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True)
CACHE_DIR.mkdir(exist_ok=True)

# =============================================================================
# STARTUP DEFINITIONS
# =============================================================================

STARTUPS = {
    # --- Existing Case Studies (3) ---
    "groq": {
        "name": "Groq Inc.",
        "industry": "AI Chips/Infrastructure",
        "business_model": "Hardware + Cloud API",
        "revenue_2025": 172_500_000,  # $172.5M (June 2025 run-rate)
        "arr_2025": None,
        "valuation": 20_000_000_000,  # $20B (Nvidia deal, Dec 2025)
        "deal_type": "strategic_ma",
        "deal_date": "2025-12",
        "growth_rate_pct": 5400,  # From $3M to ~$172M
        "de_ratio_pct": 0,  # VC-backed, no debt
        "peers": ["NVDA", "AMD", "INTC", "MRVL"],
        "founded": 2016,
        "employees": 624,
        "total_raised": 3_250_000_000,
        "data_source": "existing"
    },

    "harvey": {
        "name": "Harvey AI",
        "industry": "Legal AI",
        "business_model": "Enterprise SaaS",
        "revenue_2025": None,
        "arr_2025": 150_000_000,  # $150M ARR
        "valuation": 8_000_000_000,  # $8B (Growth Round, Oct 2025)
        "deal_type": "vc_growth",
        "deal_date": "2025-10",
        "growth_rate_pct": 500,  # 6x YoY
        "de_ratio_pct": 0,
        "peers": ["LZ", "TRI", "RELX", "AI", "PLTR"],
        "founded": 2022,
        "employees": 400,
        "total_raised": 656_000_000,
        "data_source": "existing"
    },

    "manus": {
        "name": "Manus AI",
        "industry": "AI Agents",
        "business_model": "Enterprise SaaS",
        "revenue_2025": 125_000_000,  # $125M run-rate
        "arr_2025": 100_000_000,  # $100M ARR (world record: 8 months)
        "valuation": 2_500_000_000,  # $2-3B (Meta acquisition, Dec 2025)
        "deal_type": "strategic_ma",
        "deal_date": "2025-12",
        "growth_rate_pct": 300,
        "de_ratio_pct": 0,
        "peers": ["PATH", "NOW", "CRM"],
        "founded": 2022,
        "employees": 105,
        "total_raised": 85_000_000,
        "data_source": "existing"
    },

    # --- Extended Dataset (5) ---
    "openai": {
        "name": "OpenAI",
        "industry": "Foundation Models",
        "business_model": "API + Consumer Products",
        "revenue_2025": None,
        "arr_2025": 17_500_000_000,  # ~$17.5B (midpoint estimate)
        "valuation": 500_000_000_000,  # $500B (late 2025 estimates)
        "deal_type": "late_stage_vc",
        "deal_date": "2025-10",
        "growth_rate_pct": 200,
        "de_ratio_pct": 0,
        "peers": ["GOOGL", "MSFT", "META", "NVDA"],
        "founded": 2015,
        "employees": 3000,
        "total_raised": 23_000_000_000,
        "data_source": "public_reports"
    },

    "anthropic": {
        "name": "Anthropic",
        "industry": "Foundation Models",
        "business_model": "API + Enterprise",
        "revenue_2025": None,
        "arr_2025": 8_000_000_000,  # ~$8B ARR estimate
        "valuation": 183_000_000_000,  # $183B (Dec 2025)
        "deal_type": "vc_growth",
        "deal_date": "2025-12",
        "growth_rate_pct": 150,
        "de_ratio_pct": 0,
        "peers": ["GOOGL", "MSFT", "META"],
        "founded": 2021,
        "employees": 1000,
        "total_raised": 15_000_000_000,
        "data_source": "public_reports"
    },

    "xai": {
        "name": "xAI",
        "industry": "Foundation Models",
        "business_model": "API + Consumer (Grok)",
        "revenue_2025": 1_000_000_000,  # ~$1B estimate
        "arr_2025": None,
        "valuation": 230_000_000_000,  # $230B (strategic premium)
        "deal_type": "strategic_premium",
        "deal_date": "2025-11",
        "growth_rate_pct": 1000,
        "de_ratio_pct": 0,
        "peers": ["TSLA", "GOOGL", "META"],  # Musk ecosystem
        "founded": 2023,
        "employees": 500,
        "total_raised": 12_000_000_000,
        "data_source": "public_reports"
    },

    "perplexity": {
        "name": "Perplexity AI",
        "industry": "AI Search",
        "business_model": "Freemium + Enterprise",
        "revenue_2025": None,
        "arr_2025": 200_000_000,  # $200M ARR
        "valuation": 22_000_000_000,  # $22B (late 2025)
        "deal_type": "vc_growth",
        "deal_date": "2025-09",
        "growth_rate_pct": 300,
        "de_ratio_pct": 0,
        "peers": ["GOOGL", "AI", "PLTR"],
        "founded": 2022,
        "employees": 300,
        "total_raised": 900_000_000,
        "data_source": "public_reports"
    },

    "databricks": {
        "name": "Databricks",
        "industry": "Data/AI Platform",
        "business_model": "Enterprise SaaS",
        "revenue_2025": None,
        "arr_2025": 4_800_000_000,  # $4.8B ARR
        "valuation": 134_000_000_000,  # $134B (late 2025)
        "deal_type": "late_stage_vc",
        "deal_date": "2025-10",
        "growth_rate_pct": 55,
        "de_ratio_pct": 0,
        "peers": ["SNOW", "DDOG", "MDB", "ESTC"],
        "founded": 2013,
        "employees": 7000,
        "total_raised": 4_100_000_000,
        "data_source": "public_reports"
    }
}

# =============================================================================
# VALUATION PARAMETERS
# =============================================================================

VALUATION_PARAMS = {
    # Risk-free rate (10-Year US Treasury, Dec 2025)
    "risk_free_rate": 0.043,  # 4.3%

    # Equity Risk Premium (Damodaran 2025 estimate)
    "equity_risk_premium": 0.055,  # 5.5%

    # Corporate tax rate
    "tax_rate": 0.21,  # 21%

    # Size premiums (Duff & Phelps)
    "size_premiums": {
        "early_stage": 0.06,    # <$100M revenue: 6%
        "growth_stage": 0.05,   # $100M-$1B: 5%
        "late_stage": 0.03      # >$1B: 3%
    },

    # DLOM (Discount for Lack of Marketability)
    "dlom": {
        "early_stage": 0.30,    # 30%
        "growth_stage": 0.25,   # 25%
        "late_stage": 0.15      # 15%
    }
}

# =============================================================================
# PEER SELECTION SCENARIOS
# =============================================================================

PEER_SCENARIOS = {
    "aggressive_growth": {
        "name": "Aggressive Growth Peers",
        "description": "High-growth tech companies with elevated multiples",
        "peers": ["NVDA", "CRM", "SNOW", "DDOG"],
        "expected_multiple_range": "15-40x"
    },

    "conservative_value": {
        "name": "Conservative Value Peers",
        "description": "Established tech with moderate multiples",
        "peers": ["MSFT", "ORCL", "IBM", "SAP"],
        "expected_multiple_range": "5-12x"
    },

    "ai_focused": {
        "name": "AI-Native Peers",
        "description": "Pure-play AI companies",
        "peers": ["PLTR", "AI", "PATH", "SNOW"],
        "expected_multiple_range": "8-25x"
    },

    "saas_median": {
        "name": "SaaS Median Peers",
        "description": "Representative SaaS companies",
        "peers": ["NOW", "WDAY", "ZM", "TEAM"],
        "expected_multiple_range": "8-20x"
    }
}

# =============================================================================
# CUSTOM STARTUP TEMPLATES
# =============================================================================

CUSTOM_TEMPLATES = {
    "template_early_ai": {
        "name": "Early-Stage AI Startup",
        "description": "Pre-revenue to $10M, seed to Series A",
        "revenue_2025": 10_000_000,
        "valuation": 100_000_000,
        "growth_rate_pct": 200,
        "de_ratio_pct": 0,
        "peers": ["AI", "PLTR", "PATH"],
        "deal_type": "vc_early"
    },

    "template_growth_saas": {
        "name": "Growth SaaS ($50M ARR)",
        "description": "Series B-C, proven product-market fit",
        "arr_2025": 50_000_000,
        "valuation": 500_000_000,
        "growth_rate_pct": 100,
        "de_ratio_pct": 0,
        "peers": ["CRM", "NOW", "WDAY"],
        "deal_type": "vc_growth"
    },

    "template_late_stage": {
        "name": "Late-Stage Unicorn ($500M ARR)",
        "description": "Pre-IPO, significant scale",
        "arr_2025": 500_000_000,
        "valuation": 5_000_000_000,
        "growth_rate_pct": 50,
        "de_ratio_pct": 0,
        "peers": ["SNOW", "DDOG", "MDB"],
        "deal_type": "late_stage_vc"
    },

    "template_ai_infra": {
        "name": "AI Infrastructure ($100M Rev)",
        "description": "Hardware or cloud infrastructure focus",
        "revenue_2025": 100_000_000,
        "valuation": 2_000_000_000,
        "growth_rate_pct": 150,
        "de_ratio_pct": 0,
        "peers": ["NVDA", "AMD", "MRVL"],
        "deal_type": "vc_growth"
    },

    "template_vertical_ai": {
        "name": "Vertical AI SaaS ($30M ARR)",
        "description": "Industry-specific AI application",
        "arr_2025": 30_000_000,
        "valuation": 300_000_000,
        "growth_rate_pct": 120,
        "de_ratio_pct": 0,
        "peers": ["AI", "PLTR", "NOW"],
        "deal_type": "vc_growth"
    }
}

# =============================================================================
# DEAL TYPE CLASSIFICATIONS
# =============================================================================

DEAL_TYPES = {
    "vc_early": {
        "name": "Early-Stage VC",
        "description": "Seed to Series A",
        "typical_multiple_premium": 0.0,
        "dlom_adjustment": 0.30
    },
    "vc_growth": {
        "name": "Growth-Stage VC",
        "description": "Series B-D",
        "typical_multiple_premium": 0.0,
        "dlom_adjustment": 0.25
    },
    "late_stage_vc": {
        "name": "Late-Stage / Pre-IPO",
        "description": "Series E+ or crossover",
        "typical_multiple_premium": 0.10,  # 10% premium for liquidity path
        "dlom_adjustment": 0.15
    },
    "strategic_ma": {
        "name": "Strategic M&A",
        "description": "Acquisition by strategic buyer",
        "typical_multiple_premium": 0.30,  # 30% control premium
        "dlom_adjustment": 0.0  # Full liquidity
    },
    "strategic_premium": {
        "name": "Strategic Premium",
        "description": "Unique asset with limited competition",
        "typical_multiple_premium": 0.50,  # 50%+ premium
        "dlom_adjustment": 0.0
    }
}

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_revenue(startup: dict) -> float:
    """Get revenue or ARR for a startup."""
    return startup.get("revenue_2025") or startup.get("arr_2025") or 0

def get_size_stage(startup: dict) -> str:
    """Determine size stage based on revenue."""
    revenue = get_revenue(startup)
    if revenue < 100_000_000:
        return "early_stage"
    elif revenue < 1_000_000_000:
        return "growth_stage"
    else:
        return "late_stage"

def get_size_premium(startup: dict) -> float:
    """Get size premium based on revenue stage."""
    stage = get_size_stage(startup)
    return VALUATION_PARAMS["size_premiums"][stage]

def get_dlom(startup: dict) -> float:
    """Get DLOM based on revenue stage and deal type."""
    deal_type = startup.get("deal_type", "vc_growth")
    if deal_type in ["strategic_ma", "strategic_premium"]:
        return 0.0  # No DLOM for M&A

    stage = get_size_stage(startup)
    return VALUATION_PARAMS["dlom"][stage]
