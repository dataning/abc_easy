"""
Backtest Runner

Orchestrates backtesting across all startups and scenarios.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from .config import STARTUPS, PEER_SCENARIOS, DATA_DIR, get_revenue
from .data_fetcher import PeerDataFetcher
from .valuation_engine import ValuationEngine
from .metrics import AccuracyMetrics

logger = logging.getLogger(__name__)


class BacktestRunner:
    """
    Run backtesting experiments across startups.

    Core questions:
    1. How does comparable selection affect valuation accuracy?
    2. Which approach is more reliable for different startup types?
    """

    def __init__(self, use_cache: bool = True):
        """
        Initialize the backtest runner.

        Args:
            use_cache: Whether to use cached peer data
        """
        self.fetcher = PeerDataFetcher()
        self.engine = ValuationEngine()
        self.use_cache = use_cache
        self.results = []

    def run_full_backtest(
        self,
        startups: Dict = None,
        save_results: bool = True
    ) -> Dict:
        """
        Run backtesting on all startups.

        Args:
            startups: Dictionary of startups (defaults to STARTUPS)
            save_results: Whether to save results to JSON

        Returns:
            Complete backtest results
        """
        startups = startups or STARTUPS
        self.results = []

        logger.info(f"Starting backtest on {len(startups)} startups...")

        for startup_id, startup_data in startups.items():
            try:
                result = self.backtest_single(startup_id, startup_data)
                self.results.append(result)
                logger.info(f"  {startup_data['name']}: Gap={result['approach_1']['gap']:.1f}x, CoE={result['approach_2']['cost_of_equity_pct']:.1f}%")
            except Exception as e:
                logger.error(f"Error backtesting {startup_id}: {e}")
                self.results.append({
                    "startup_id": startup_id,
                    "error": str(e)
                })

        # Aggregate results
        aggregated = self.aggregate_results()

        if save_results:
            self._save_results(aggregated)

        return aggregated

    def backtest_single(
        self,
        startup_id: str,
        startup: Dict
    ) -> Dict:
        """
        Backtest both approaches on a single startup.

        Args:
            startup_id: Unique identifier for the startup
            startup: Startup data dictionary

        Returns:
            Complete results for this startup
        """
        # Fetch peer data
        peers = startup.get("peers", [])
        peers_df = self.fetcher.fetch_peer_group(peers, use_cache=self.use_cache)
        peer_stats = self.fetcher.get_peer_statistics(peers_df)

        # Run both approaches
        approach_1 = self.engine.approach_1_trading_multiples(startup, peer_stats)
        approach_2 = self.engine.approach_2_bottom_up_beta(startup, peer_stats)

        # Run expectations analysis (Current Speed vs Required Speed)
        cost_of_equity = approach_2.get("cost_of_equity", 0.18)
        expectations = self.engine.expectations_analysis(startup, cost_of_equity)

        # Format peer table for display
        peer_table = self.fetcher.format_peer_table(peers_df)

        return {
            "startup_id": startup_id,
            "startup_data": startup,
            "peer_data": peer_table,
            "peer_statistics": peer_stats,
            "approach_1": approach_1,
            "approach_2": approach_2,
            "expectations": expectations,
            "timestamp": datetime.now().isoformat()
        }

    def test_comparable_sensitivity(
        self,
        startup_id: str,
        peer_scenarios: Dict = None
    ) -> List[Dict]:
        """
        Test how different peer selections affect valuations.

        Key backtesting question: sensitivity to comparable selection.

        Args:
            startup_id: Startup to test
            peer_scenarios: Different peer group configurations

        Returns:
            List of results for each peer scenario
        """
        peer_scenarios = peer_scenarios or PEER_SCENARIOS
        startup = STARTUPS.get(startup_id)

        if not startup:
            raise ValueError(f"Unknown startup: {startup_id}")

        results = []

        for scenario_name, scenario_config in peer_scenarios.items():
            # Create test version with different peers
            test_startup = {**startup, "peers": scenario_config["peers"]}

            try:
                result = self.backtest_single(f"{startup_id}_{scenario_name}", test_startup)
                result["peer_scenario"] = scenario_name
                result["peer_scenario_description"] = scenario_config["description"]
                results.append(result)
            except Exception as e:
                logger.error(f"Error testing {startup_id} with {scenario_name}: {e}")

        return results

    def run_sensitivity_analysis(
        self,
        startup_ids: List[str] = None
    ) -> Dict:
        """
        Run sensitivity analysis across multiple startups.

        Args:
            startup_ids: List of startups to analyze (defaults to all)

        Returns:
            Sensitivity analysis results
        """
        startup_ids = startup_ids or list(STARTUPS.keys())
        sensitivity_results = {}

        for startup_id in startup_ids:
            logger.info(f"Running sensitivity for {startup_id}...")
            try:
                results = self.test_comparable_sensitivity(startup_id)
                sensitivity_results[startup_id] = {
                    "results": results,
                    "summary": AccuracyMetrics.sensitivity_summary(results)
                }
            except Exception as e:
                logger.error(f"Sensitivity error for {startup_id}: {e}")
                sensitivity_results[startup_id] = {"error": str(e)}

        return sensitivity_results

    def aggregate_results(self) -> Dict:
        """
        Calculate overall accuracy metrics.

        Returns:
            Aggregated backtest results
        """
        valid_results = [r for r in self.results if "error" not in r]

        return {
            "summary": {
                "total_startups": len(STARTUPS),
                "successful_backtests": len(valid_results),
                "timestamp": datetime.now().isoformat()
            },

            # Individual results
            "results": self.results,

            # Approach comparison
            "approach_comparison": AccuracyMetrics.compare_approaches(valid_results),

            # Groupings
            "by_deal_type": AccuracyMetrics.group_by_deal_type(valid_results),
            "by_growth_rate": AccuracyMetrics.group_by_growth_rate(valid_results),

            # Formatted for display
            "display_data": self._format_for_display(valid_results)
        }

    def _format_for_display(self, results: List[Dict]) -> Dict:
        """Format results for HTML display."""
        # Summary stats
        gaps = [r["approach_1"]["gap"] for r in results if "approach_1" in r]
        coes = [r["approach_2"]["cost_of_equity_pct"] for r in results if "approach_2" in r]

        # Startup table data
        startup_rows = []
        for r in results:
            startup = r.get("startup_data", {})
            a1 = r.get("approach_1", {})
            a2 = r.get("approach_2", {})
            exp = r.get("expectations", {})

            revenue = get_revenue(startup)

            # Extract expectations data
            current_metrics = exp.get("current_metrics", {})
            verdict = exp.get("verdict", {})
            thresholds = exp.get("valuation_thresholds", {})
            projected = exp.get("projected_valuation", {})

            # Extract threshold data
            threshold_list = []
            for key in ["threshold_1", "threshold_2", "threshold_3", "threshold_4"]:
                if key in thresholds:
                    t = thresholds[key]
                    threshold_list.append({
                        "target": t.get("target_display", "N/A"),
                        "target_raw": t.get("target_valuation", 0),
                        "required_cagr": t.get("required_cagr_pct", 0),
                        "probability": t.get("probability_pct", 0),
                        "probability_rating": t.get("probability_rating", "N/A"),
                        "difficulty": t.get("difficulty", "N/A"),
                        "is_upside": t.get("is_upside", True)
                    })

            startup_rows.append({
                "name": startup.get("name", "Unknown"),
                "industry": startup.get("industry", ""),
                "revenue": self._format_currency(revenue),
                "revenue_raw": revenue,
                "actual_valuation": self._format_currency(startup.get("valuation", 0)),
                "actual_valuation_raw": startup.get("valuation", 0),
                "implied_valuation": self._format_currency(a1.get("implied_valuation", 0)),
                "gap": a1.get("gap", 0),
                "gap_display": f"{a1.get('gap', 0):.1f}x",
                "gap_color": AccuracyMetrics.gap_color(a1.get("gap", 0)),
                "gap_category": AccuracyMetrics.gap_category(a1.get("gap", 0)),
                "implied_multiple": a1.get("implied_market_multiple", 0),
                "peer_multiple": a1.get("peer_median_multiple", 0),
                "cost_of_equity": a2.get("cost_of_equity_pct", 0),
                "coe_display": f"{a2.get('cost_of_equity_pct', 0):.1f}%",
                "beta": a2.get("relevered_beta", 0),
                "deal_type": startup.get("deal_type", ""),
                "growth_rate": startup.get("growth_rate_pct", 0),
                "peers_used": ", ".join(startup.get("peers", [])),
                # Expectations analysis - new threshold-based
                "current_growth_pct": current_metrics.get("current_growth_rate_pct", 0),
                "current_multiple": current_metrics.get("current_multiple", 0),
                "thresholds": threshold_list,
                "projected_y5_valuation": projected.get("year_5_valuation_display", "N/A"),
                "verdict_status": verdict.get("status", "unknown"),
                "verdict_color": verdict.get("color", "#6b7280"),
                "verdict_message": verdict.get("message", ""),
                "verdict_recommendation": verdict.get("recommendation", ""),
            })

        # Sort by gap (descending)
        startup_rows.sort(key=lambda x: x["gap"], reverse=True)

        return {
            "summary_stats": {
                "total_startups": len(results),
                "total_valuation": self._format_currency(sum(r.get("startup_data", {}).get("valuation", 0) for r in results)),
                "avg_gap": round(sum(gaps) / len(gaps), 1) if gaps else 0,
                "median_gap": round(sorted(gaps)[len(gaps)//2], 1) if gaps else 0,
                "avg_coe": round(sum(coes) / len(coes), 1) if coes else 0,
                "coe_range": f"{min(coes):.1f}%-{max(coes):.1f}%" if coes else "N/A"
            },
            "startup_table": startup_rows,
            "chart_data": {
                "gap_chart": [{"name": r["name"], "gap": r["gap"], "color": r["gap_color"]} for r in startup_rows],
                "coe_chart": [{"name": r["name"], "coe": r["cost_of_equity"]} for r in startup_rows]
            }
        }

    def _format_currency(self, value: float) -> str:
        """Format currency value for display."""
        if value >= 1e12:
            return f"${value/1e12:.1f}T"
        elif value >= 1e9:
            return f"${value/1e9:.1f}B"
        elif value >= 1e6:
            return f"${value/1e6:.1f}M"
        else:
            return f"${value:,.0f}"

    def _save_results(self, results: Dict) -> Path:
        """Save results to JSON file."""
        output_path = DATA_DIR / "backtest_results.json"
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"Results saved to {output_path}")
        return output_path


# =============================================================================
# QUICK TEST FUNCTIONS
# =============================================================================

def quick_test():
    """Quick test of backtesting functionality."""
    logging.basicConfig(level=logging.INFO)

    runner = BacktestRunner()

    # Test single startup
    print("\n=== Testing Single Startup (Groq) ===")
    result = runner.backtest_single("groq", STARTUPS["groq"])
    print(f"Gap: {result['approach_1']['gap']:.1f}x")
    print(f"CoE: {result['approach_2']['cost_of_equity_pct']:.1f}%")

    # Test full backtest
    print("\n=== Running Full Backtest ===")
    full_results = runner.run_full_backtest()
    print(f"Avg Gap: {full_results['display_data']['summary_stats']['avg_gap']:.1f}x")
    print(f"Avg CoE: {full_results['display_data']['summary_stats']['avg_coe']:.1f}%")

    return full_results


if __name__ == "__main__":
    quick_test()
