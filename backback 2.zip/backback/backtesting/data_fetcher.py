"""
Data Fetcher for Peer Company Data

Fetches financial data from Yahoo Finance with caching.
Calculates key metrics for valuation analysis.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import pandas as pd

try:
    import yfinance as yf
except ImportError:
    yf = None
    logging.warning("yfinance not installed. Run: pip install yfinance")

from .config import CACHE_DIR, VALUATION_PARAMS

logger = logging.getLogger(__name__)


class PeerDataFetcher:
    """Fetch and cache peer company data from Yahoo Finance."""

    def __init__(self, cache_dir: Path = CACHE_DIR, cache_hours: int = 24):
        """
        Initialize the fetcher.

        Args:
            cache_dir: Directory to store cached data
            cache_hours: How long to keep cached data (default 24 hours)
        """
        self.cache_dir = cache_dir
        self.cache_duration = timedelta(hours=cache_hours)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _get_cache_path(self, ticker: str) -> Path:
        """Get cache file path for a ticker."""
        today = datetime.now().strftime("%Y-%m-%d")
        return self.cache_dir / f"{ticker}_{today}.json"

    def _is_cache_valid(self, cache_path: Path) -> bool:
        """Check if cache file exists and is still valid."""
        if not cache_path.exists():
            return False

        modified_time = datetime.fromtimestamp(cache_path.stat().st_mtime)
        return datetime.now() - modified_time < self.cache_duration

    def _load_from_cache(self, ticker: str) -> Optional[Dict]:
        """Load data from cache if valid."""
        cache_path = self._get_cache_path(ticker)
        if self._is_cache_valid(cache_path):
            try:
                with open(cache_path, 'r') as f:
                    data = json.load(f)
                    logger.debug(f"Loaded {ticker} from cache")
                    return data
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"Failed to load cache for {ticker}: {e}")
        return None

    def _save_to_cache(self, ticker: str, data: Dict) -> None:
        """Save data to cache."""
        cache_path = self._get_cache_path(ticker)
        try:
            with open(cache_path, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            logger.debug(f"Saved {ticker} to cache")
        except IOError as e:
            logger.warning(f"Failed to save cache for {ticker}: {e}")

    def fetch_peer(self, ticker: str, use_cache: bool = True) -> Dict:
        """
        Fetch financial data for a single peer company.

        Args:
            ticker: Stock ticker symbol
            use_cache: Whether to use cached data if available

        Returns:
            Dictionary with company financial data
        """
        # Check cache first
        if use_cache:
            cached = self._load_from_cache(ticker)
            if cached:
                return cached

        if yf is None:
            raise ImportError("yfinance is required. Run: pip install yfinance")

        # Fetch from Yahoo Finance
        try:
            stock = yf.Ticker(ticker)
            info = stock.info

            # Extract key metrics
            data = {
                "ticker": ticker,
                "name": info.get("shortName", ticker),
                "sector": info.get("sector", "Technology"),
                "industry": info.get("industry", ""),

                # Market data
                "market_cap": info.get("marketCap", 0),
                "enterprise_value": info.get("enterpriseValue", 0),
                "current_price": info.get("currentPrice", info.get("regularMarketPrice", 0)),

                # Revenue metrics
                "revenue_ttm": info.get("totalRevenue", 0),
                "revenue_growth": info.get("revenueGrowth", 0),

                # Profitability
                "ebitda": info.get("ebitda", 0),
                "gross_margin": info.get("grossMargins", 0),
                "operating_margin": info.get("operatingMargins", 0),
                "profit_margin": info.get("profitMargins", 0),

                # Balance sheet
                "total_debt": info.get("totalDebt", 0),
                "total_cash": info.get("totalCash", 0),
                "shares_outstanding": info.get("sharesOutstanding", 0),

                # Risk metrics
                "beta": info.get("beta", 1.0),

                # Calculated metrics (will be computed below)
                "de_ratio_pct": 0,
                "ev_revenue": 0,
                "ev_ebitda": 0,
                "unlevered_beta": 0,

                # Metadata
                "fetch_date": datetime.now().isoformat(),
                "data_source": "yfinance"
            }

            # Calculate derived metrics
            data = self._calculate_derived_metrics(data)

            # Cache the result
            if use_cache:
                self._save_to_cache(ticker, data)

            logger.info(f"Fetched {ticker}: EV/Rev={data['ev_revenue']:.1f}x, Beta={data['beta']:.2f}")
            return data

        except Exception as e:
            logger.error(f"Failed to fetch {ticker}: {e}")
            return self._get_fallback_data(ticker)

    def _calculate_derived_metrics(self, data: Dict) -> Dict:
        """Calculate derived financial metrics."""
        # D/E Ratio
        if data["market_cap"] and data["market_cap"] > 0:
            data["de_ratio_pct"] = (data["total_debt"] / data["market_cap"]) * 100
        else:
            data["de_ratio_pct"] = 0

        # EV/Revenue
        if data["revenue_ttm"] and data["revenue_ttm"] > 0:
            data["ev_revenue"] = data["enterprise_value"] / data["revenue_ttm"]
        else:
            data["ev_revenue"] = 0

        # EV/EBITDA
        if data["ebitda"] and data["ebitda"] > 0:
            data["ev_ebitda"] = data["enterprise_value"] / data["ebitda"]
        else:
            data["ev_ebitda"] = 0

        # Unlevered Beta (Hamada equation)
        data["unlevered_beta"] = self.calculate_unlevered_beta(
            data["beta"],
            data["de_ratio_pct"]
        )

        return data

    def _get_fallback_data(self, ticker: str) -> Dict:
        """Return fallback data when fetch fails."""
        return {
            "ticker": ticker,
            "name": ticker,
            "market_cap": 0,
            "enterprise_value": 0,
            "revenue_ttm": 0,
            "beta": 1.0,
            "de_ratio_pct": 0,
            "ev_revenue": 0,
            "unlevered_beta": 1.0,
            "fetch_date": datetime.now().isoformat(),
            "data_source": "fallback",
            "error": "Fetch failed"
        }

    def fetch_peer_group(self, tickers: List[str], use_cache: bool = True) -> pd.DataFrame:
        """
        Fetch data for multiple peer companies.

        Args:
            tickers: List of stock ticker symbols
            use_cache: Whether to use cached data

        Returns:
            DataFrame with all peer data
        """
        peers_data = []
        for ticker in tickers:
            try:
                data = self.fetch_peer(ticker, use_cache=use_cache)
                peers_data.append(data)
            except Exception as e:
                logger.error(f"Error fetching {ticker}: {e}")
                peers_data.append(self._get_fallback_data(ticker))

        df = pd.DataFrame(peers_data)
        return df

    def calculate_unlevered_beta(self, levered_beta: float, de_ratio_pct: float) -> float:
        """
        Calculate unlevered beta using Hamada equation.

        Formula: β_u = β_L / [1 + (1-T) × (D/E)]

        Args:
            levered_beta: Observed (levered) beta
            de_ratio_pct: Debt-to-Equity ratio in percentage

        Returns:
            Unlevered beta
        """
        if levered_beta is None or levered_beta <= 0:
            return 1.0

        tax_rate = VALUATION_PARAMS["tax_rate"]
        de_ratio = de_ratio_pct / 100

        unlevered = levered_beta / (1 + (1 - tax_rate) * de_ratio)
        return round(unlevered, 4)

    def relever_beta(self, unlevered_beta: float, target_de_ratio_pct: float) -> float:
        """
        Re-lever beta for target capital structure.

        Formula: β_T = β_u × [1 + (1-T) × (D/E)]

        Args:
            unlevered_beta: Unlevered (asset) beta
            target_de_ratio_pct: Target D/E ratio in percentage

        Returns:
            Re-levered beta for target company
        """
        tax_rate = VALUATION_PARAMS["tax_rate"]
        de_ratio = target_de_ratio_pct / 100

        relevered = unlevered_beta * (1 + (1 - tax_rate) * de_ratio)
        return round(relevered, 4)

    def get_peer_statistics(self, peers_df: pd.DataFrame) -> Dict:
        """
        Calculate summary statistics for peer group.

        Args:
            peers_df: DataFrame with peer company data

        Returns:
            Dictionary with median and mean statistics
        """
        # Filter out invalid data
        valid_df = peers_df[peers_df["ev_revenue"] > 0].copy()

        if len(valid_df) == 0:
            return {
                "count": 0,
                "median_ev_revenue": 0,
                "mean_ev_revenue": 0,
                "median_ev_ebitda": 0,
                "median_beta": 1.0,
                "median_unlevered_beta": 1.0,
                "median_de_ratio": 0,
                "peers_used": []
            }

        return {
            "count": len(valid_df),
            "peers_used": valid_df["ticker"].tolist(),

            # EV/Revenue multiples
            "median_ev_revenue": round(valid_df["ev_revenue"].median(), 2),
            "mean_ev_revenue": round(valid_df["ev_revenue"].mean(), 2),
            "min_ev_revenue": round(valid_df["ev_revenue"].min(), 2),
            "max_ev_revenue": round(valid_df["ev_revenue"].max(), 2),

            # EV/EBITDA multiples
            "median_ev_ebitda": round(valid_df["ev_ebitda"].median(), 2) if "ev_ebitda" in valid_df else 0,

            # Beta statistics
            "median_beta": round(valid_df["beta"].median(), 3),
            "mean_beta": round(valid_df["beta"].mean(), 3),
            "median_unlevered_beta": round(valid_df["unlevered_beta"].median(), 3),
            "mean_unlevered_beta": round(valid_df["unlevered_beta"].mean(), 3),

            # Capital structure
            "median_de_ratio": round(valid_df["de_ratio_pct"].median(), 2),

            # Revenue growth
            "median_revenue_growth": round(valid_df["revenue_growth"].median() * 100, 1) if "revenue_growth" in valid_df else 0
        }

    def format_peer_table(self, peers_df: pd.DataFrame) -> List[Dict]:
        """
        Format peer data for display in HTML table.

        Args:
            peers_df: DataFrame with peer data

        Returns:
            List of dictionaries formatted for table display
        """
        formatted = []
        for _, row in peers_df.iterrows():
            formatted.append({
                "ticker": row["ticker"],
                "name": row.get("name", row["ticker"]),
                "market_cap_b": f"${row['market_cap'] / 1e9:.1f}B" if row["market_cap"] > 0 else "N/A",
                "ev_b": f"${row['enterprise_value'] / 1e9:.1f}B" if row["enterprise_value"] > 0 else "N/A",
                "ev_revenue": f"{row['ev_revenue']:.1f}x" if row["ev_revenue"] > 0 else "N/A",
                "beta": f"{row['beta']:.2f}" if row["beta"] else "N/A",
                "unlevered_beta": f"{row['unlevered_beta']:.2f}" if row["unlevered_beta"] else "N/A",
                "de_ratio": f"{row['de_ratio_pct']:.1f}%" if row["de_ratio_pct"] else "0%"
            })
        return formatted


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def clear_cache(cache_dir: Path = CACHE_DIR) -> int:
    """
    Clear all cached data.

    Returns:
        Number of files deleted
    """
    count = 0
    for f in cache_dir.glob("*.json"):
        f.unlink()
        count += 1
    logger.info(f"Cleared {count} cached files")
    return count


def get_cache_info(cache_dir: Path = CACHE_DIR) -> Dict:
    """
    Get information about cached data.

    Returns:
        Dictionary with cache statistics
    """
    files = list(cache_dir.glob("*.json"))
    total_size = sum(f.stat().st_size for f in files)

    tickers = set()
    for f in files:
        parts = f.stem.split("_")
        if parts:
            tickers.add(parts[0])

    return {
        "total_files": len(files),
        "total_size_kb": round(total_size / 1024, 2),
        "unique_tickers": len(tickers),
        "tickers": sorted(tickers)
    }
