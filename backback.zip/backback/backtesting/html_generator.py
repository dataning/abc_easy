"""
HTML Generator

Generates static HTML page with backtesting results.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict

from .config import BASE_DIR, PEER_SCENARIOS, CUSTOM_TEMPLATES


class HTMLGenerator:
    """Generate static HTML pages with backtesting results."""

    def __init__(self):
        """Initialize the HTML generator."""
        self.output_dir = BASE_DIR

    def generate_backtest_page(
        self,
        backtest_results: Dict,
        scenario_data: Dict,
        output_filename: str = "valuation_backtest.html"
    ) -> Path:
        """
        Generate the main backtesting results page.

        Args:
            backtest_results: Results from BacktestRunner
            scenario_data: Pre-computed scenarios for interactivity
            output_filename: Output HTML filename

        Returns:
            Path to generated HTML file
        """
        html = self._build_html(backtest_results, scenario_data)
        output_path = self.output_dir / output_filename

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)

        return output_path

    def _build_html(self, results: Dict, scenarios: Dict) -> str:
        """Build complete HTML document."""
        display_data = results.get("display_data", {})
        summary = display_data.get("summary_stats", {})
        startup_table = display_data.get("startup_table", [])
        comparison = results.get("approach_comparison", {})

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valuation Backtesting: Trading Multiples vs. Bottom-Up Beta</title>

    <!-- KaTeX for Math Rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"
        onload="renderMathInElement(document.body, {{
            delimiters: [
                {{left: '$$', right: '$$', display: true}},
                {{left: '$', right: '$', display: false}}
            ]
        }});"></script>

    <style>
        {self._get_css_styles()}
    </style>
</head>
<body>

<!-- LEARNING-PORTAL-NAV -->

{self._build_hero_section(summary)}

<div class="container">
    {self._build_executive_summary(summary, comparison)}

    {self._build_startup_table(startup_table)}

    {self._build_gap_analysis_chart(startup_table)}

    {self._build_methodology_comparison(comparison)}

    {self._build_expectations_section(startup_table)}

    {self._build_sensitivity_section(scenarios)}

    {self._build_conclusions(comparison)}

    {self._build_data_sources(results)}
</div>

<footer>
    <p>Valuation Backtesting | Trading Multiples vs. Bottom-Up Beta</p>
    <p style="margin-top: 0.5rem; font-size: 0.9rem;">
        Empirical analysis of {summary.get('total_startups', 8)} AI startups
    </p>
</footer>

<script>
{self._get_javascript(scenarios)}
</script>

</body>
</html>'''

    def _get_css_styles(self) -> str:
        """Return CSS styles."""
        return '''
        :root {
            --primary-blue: #1a5f7a;
            --secondary-blue: #57c5b6;
            --accent-orange: #f97316;
            --accent-purple: #8b5cf6;
            --success-green: #10b981;
            --warning-yellow: #f59e0b;
            --danger-red: #ef4444;
            --bg-light: #f8fafc;
            --bg-card: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.7;
            color: var(--text-dark);
            background: var(--bg-light);
        }

        .hero {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
            color: white;
            padding: 4rem 2rem;
            text-align: center;
            position: relative;
        }

        .hero h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            font-weight: 700;
        }

        .hero .subtitle {
            font-size: 1.25rem;
            opacity: 0.9;
            max-width: 800px;
            margin: 0 auto;
        }

        .hero .badges {
            margin-top: 1.5rem;
            display: flex;
            justify-content: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .hero .badge {
            background: rgba(255,255,255,0.15);
            padding: 0.5rem 1.5rem;
            border-radius: 2rem;
            font-size: 0.95rem;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .section {
            background: var(--bg-card);
            border-radius: 1rem;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }

        .section h2 {
            color: var(--primary-blue);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }

        .stat-card {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            padding: 1.5rem;
            border-radius: 0.75rem;
            text-align: center;
            border: 1px solid #bae6fd;
        }

        .stat-card.highlight {
            background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
            border-color: #86efac;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-blue);
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin-top: 0.25rem;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
            font-size: 0.9rem;
        }

        .data-table th, .data-table td {
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .data-table th {
            background: var(--bg-light);
            font-weight: 600;
            color: var(--text-muted);
            font-size: 0.8rem;
            text-transform: uppercase;
        }

        .data-table tr:hover {
            background: #f8fafc;
        }

        .gap-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-weight: 600;
            font-size: 0.85rem;
        }

        .gap-aligned { background: #dcfce7; color: #166534; }
        .gap-moderate { background: #fef3c7; color: #92400e; }
        .gap-significant { background: #fee2e2; color: #991b1b; }
        .gap-extreme { background: #fecaca; color: #7f1d1d; }
        .gap-outlier { background: #991b1b; color: white; }

        .chart-container {
            margin: 1.5rem 0;
        }

        .bar-chart {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .bar-row {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .bar-label {
            width: 120px;
            font-size: 0.85rem;
            text-align: right;
            flex-shrink: 0;
        }

        .bar-track {
            flex: 1;
            background: #e2e8f0;
            height: 24px;
            border-radius: 4px;
            overflow: hidden;
            position: relative;
        }

        .bar-fill {
            height: 100%;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding-right: 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            color: white;
            transition: width 0.5s ease;
        }

        .methodology-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 1.5rem;
        }

        .methodology-card {
            background: var(--bg-light);
            padding: 1.5rem;
            border-radius: 0.75rem;
            border-left: 4px solid var(--accent-orange);
        }

        .methodology-card.beta {
            border-left-color: var(--accent-purple);
        }

        .methodology-card h3 {
            font-size: 1.1rem;
            margin-bottom: 1rem;
        }

        .methodology-card ul {
            margin-left: 1.5rem;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .methodology-card li {
            margin-bottom: 0.5rem;
        }

        .scenario-section {
            background: linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%);
            border: 2px solid #a78bfa;
            border-radius: 1rem;
            padding: 2rem;
        }

        .scenario-controls {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        .scenario-select {
            padding: 0.75rem 1rem;
            border: 2px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            min-width: 200px;
            background: white;
        }

        .scenario-results {
            background: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            margin-top: 1rem;
        }

        .conclusions-list {
            list-style: none;
        }

        .conclusions-list li {
            padding: 1rem;
            margin-bottom: 1rem;
            background: #f0fdf4;
            border-radius: 0.5rem;
            border-left: 4px solid #10b981;
        }

        .conclusions-list li strong {
            color: #166534;
        }

        .expectations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .expectation-card {
            background: white;
            border-radius: 0.75rem;
            padding: 1.25rem;
            border: 1px solid var(--border-color);
        }

        .expectation-card.verdict-undervalued { border-left: 4px solid #10b981; }
        .expectation-card.verdict-fairly_valued { border-left: 4px solid #f59e0b; }
        .expectation-card.verdict-growth_dependent { border-left: 4px solid #f97316; }
        .expectation-card.verdict-overvalued_risk { border-left: 4px solid #ef4444; }

        .expectation-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.75rem;
        }

        .expectation-name {
            font-weight: 600;
            font-size: 1rem;
        }

        .speed-comparison {
            display: flex;
            gap: 1.5rem;
            margin: 0.75rem 0;
        }

        .speed-item {
            text-align: center;
        }

        .speed-label {
            font-size: 0.75rem;
            color: var(--text-muted);
            text-transform: uppercase;
        }

        .speed-value {
            font-size: 1.25rem;
            font-weight: 700;
        }

        .speed-value.current { color: var(--primary-blue); }
        .speed-value.required { color: var(--accent-purple); }

        .probability-bar {
            height: 8px;
            background: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 0.5rem;
        }

        .probability-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }

        .prob-high { background: #10b981; }
        .prob-moderate { background: #f59e0b; }
        .prob-low { background: #ef4444; }

        .verdict-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        /* Threshold-based expectations styles */
        .threshold-card {
            background: white;
            border-radius: 0.75rem;
            padding: 1.25rem;
            border: 1px solid var(--border-color);
            margin-bottom: 1.5rem;
        }

        .threshold-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--border-color);
        }

        .threshold-company {
            font-weight: 700;
            font-size: 1.1rem;
        }

        .threshold-meta {
            display: flex;
            gap: 1rem;
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .threshold-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
        }

        .threshold-table th {
            text-align: left;
            padding: 0.5rem;
            background: var(--bg-light);
            font-weight: 600;
            color: var(--text-muted);
            font-size: 0.75rem;
            text-transform: uppercase;
        }

        .threshold-table td {
            padding: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .threshold-row.upside { background: #f0fdf4; }
        .threshold-row.stretch { background: #fef3c7; }
        .threshold-row.aggressive { background: #fee2e2; }

        .prob-indicator {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .prob-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }

        .prob-dot.high { background: #10b981; }
        .prob-dot.moderate { background: #f59e0b; }
        .prob-dot.low { background: #ef4444; }
        .prob-dot.very-low { background: #991b1b; }

        .difficulty-badge {
            display: inline-block;
            padding: 0.15rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .difficulty-achievable { background: #dcfce7; color: #166534; }
        .difficulty-challenging { background: #fef3c7; color: #92400e; }
        .difficulty-aggressive { background: #fee2e2; color: #991b1b; }
        .difficulty-extreme { background: #991b1b; color: white; }

        footer {
            background: #1e293b;
            color: #94a3b8;
            text-align: center;
            padding: 2rem;
            margin-top: 2rem;
        }

        @media (max-width: 768px) {
            .hero h1 { font-size: 1.8rem; }
            .container { padding: 1rem; }
            .section { padding: 1.5rem; }
            .methodology-grid { grid-template-columns: 1fr; }
            .bar-label { width: 80px; font-size: 0.75rem; }
        }
        '''

    def _build_hero_section(self, summary: Dict) -> str:
        """Build the hero section."""
        return f'''
<div class="hero">
    <h1>Valuation Backtesting</h1>
    <p class="subtitle">
        Empirical analysis comparing Trading Multiples vs. Bottom-Up Beta valuation approaches
        across {summary.get('total_startups', 8)} AI startups worth {summary.get('total_valuation', '$1.1T')}.
    </p>
    <div class="badges">
        <span class="badge">{summary.get('total_startups', 8)} AI Startups</span>
        <span class="badge">{summary.get('total_valuation', '$1.1T')} Combined Value</span>
        <span class="badge">Live Yahoo Finance Data</span>
    </div>
</div>'''

    def _build_executive_summary(self, summary: Dict, comparison: Dict) -> str:
        """Build executive summary section."""
        a1 = comparison.get("approach_1", {})
        a2 = comparison.get("approach_2", {})
        winner = comparison.get("winner", "bottom_up_beta")

        winner_display = "Bottom-Up Beta" if winner == "bottom_up_beta" else "Trading Multiples"

        return f'''
<div class="section">
    <h2>Executive Summary</h2>
    <div class="stat-grid">
        <div class="stat-card">
            <div class="stat-value">{summary.get('total_startups', 8)}</div>
            <div class="stat-label">Startups Analyzed</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{summary.get('avg_gap', 10.5):.1f}x</div>
            <div class="stat-label">Average Undervaluation Gap</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{summary.get('avg_coe', 18):.1f}%</div>
            <div class="stat-label">Average Cost of Equity</div>
        </div>
        <div class="stat-card highlight">
            <div class="stat-value">{winner_display}</div>
            <div class="stat-label">More Reliable Approach</div>
        </div>
    </div>
    <p style="margin-top: 1.5rem; color: var(--text-muted);">
        <strong>Key Finding:</strong> {comparison.get('winner_reason', 'Trading multiples systematically undervalue high-growth AI startups, while Bottom-Up Beta provides a consistent discount rate framework.')}
    </p>
</div>'''

    def _build_startup_table(self, startup_table: list) -> str:
        """Build the startup comparison table."""
        rows = ""
        for row in startup_table:
            gap_class = f"gap-{row.get('gap_category', 'moderate')}"
            rows += f'''
            <tr>
                <td><strong>{row.get('name', 'Unknown')}</strong></td>
                <td>{row.get('industry', '')}</td>
                <td>{row.get('revenue', 'N/A')}</td>
                <td>{row.get('actual_valuation', 'N/A')}</td>
                <td>{row.get('implied_valuation', 'N/A')}</td>
                <td><span class="gap-badge {gap_class}">{row.get('gap_display', 'N/A')}</span></td>
                <td>{row.get('coe_display', 'N/A')}</td>
                <td>{row.get('peers_used', 'N/A')}</td>
            </tr>'''

        return f'''
<div class="section">
    <h2>Startup Valuation Analysis</h2>
    <div style="overflow-x: auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>Industry</th>
                    <th>Revenue/ARR</th>
                    <th>Actual Valuation</th>
                    <th>Multiples Implied</th>
                    <th>Gap</th>
                    <th>Cost of Equity</th>
                    <th>Peers Used</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
    </div>
</div>'''

    def _build_gap_analysis_chart(self, startup_table: list) -> str:
        """Build gap analysis bar chart."""
        # Sort by gap descending
        sorted_data = sorted(startup_table, key=lambda x: x.get('gap', 0), reverse=True)

        # Build bars
        max_gap = max(row.get('gap', 1) for row in sorted_data)
        bars = ""
        for row in sorted_data:
            gap = row.get('gap', 0)
            width_pct = min((gap / max_gap) * 100, 100) if max_gap > 0 else 0
            color = row.get('gap_color', '#6b7280')
            bars += f'''
            <div class="bar-row">
                <div class="bar-label">{row.get('name', 'Unknown')}</div>
                <div class="bar-track">
                    <div class="bar-fill" style="width: {width_pct}%; background: {color};">
                        {gap:.1f}x
                    </div>
                </div>
            </div>'''

        return f'''
<div class="section">
    <h2>Undervaluation Gap Analysis</h2>
    <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
        How much actual valuations exceed multiples-based estimates. Higher gap = multiples undervalue more.
    </p>
    <div class="chart-container">
        <div class="bar-chart">
            {bars}
        </div>
    </div>
    <div style="margin-top: 1rem; display: flex; gap: 1rem; flex-wrap: wrap; font-size: 0.85rem;">
        <span><span class="gap-badge gap-aligned">Aligned</span> &lt;2x</span>
        <span><span class="gap-badge gap-moderate">Moderate</span> 2-5x</span>
        <span><span class="gap-badge gap-significant">Significant</span> 5-10x</span>
        <span><span class="gap-badge gap-extreme">Extreme</span> 10-20x</span>
        <span><span class="gap-badge gap-outlier">Outlier</span> &gt;20x</span>
    </div>
</div>'''

    def _build_methodology_comparison(self, comparison: Dict) -> str:
        """Build methodology comparison section."""
        a1 = comparison.get("approach_1", {})
        a2 = comparison.get("approach_2", {})

        return f'''
<div class="section">
    <h2>Methodology Comparison</h2>
    <div class="methodology-grid">
        <div class="methodology-card">
            <h3 style="color: var(--accent-orange);">Approach 1: Trading Multiples</h3>
            <ul>
                <li><strong>Method:</strong> Apply median EV/Revenue from public peers</li>
                <li><strong>Output:</strong> Direct valuation estimate</li>
                <li><strong>Median Gap:</strong> {a1.get('median_gap', 10.5):.1f}x undervaluation</li>
                <li><strong>Accuracy:</strong> {a1.get('pct_within_5x', 25):.0f}% within 5x of actual</li>
                <li><strong>Best For:</strong> Stable businesses, mature industries</li>
            </ul>
            <p style="margin-top: 1rem; padding: 0.75rem; background: #fff7ed; border-radius: 0.5rem; font-size: 0.85rem;">
                {a1.get('interpretation', 'Multiples systematically undervalue high-growth AI companies')}
            </p>
        </div>
        <div class="methodology-card beta">
            <h3 style="color: var(--accent-purple);">Approach 2: Bottom-Up Beta</h3>
            <ul>
                <li><strong>Method:</strong> Derive Cost of Equity from peer betas via CAPM</li>
                <li><strong>Output:</strong> Discount rate for DCF</li>
                <li><strong>Mean CoE:</strong> {a2.get('mean_coe', 18):.1f}%</li>
                <li><strong>Consistency:</strong> {a2.get('pct_in_reasonable_range', 85):.0f}% in 15-25% range</li>
                <li><strong>Best For:</strong> Growth companies, strategic valuations</li>
            </ul>
            <p style="margin-top: 1rem; padding: 0.75rem; background: #faf5ff; border-radius: 0.5rem; font-size: 0.85rem;">
                {a2.get('interpretation', 'Provides consistent risk-adjusted framework for growth companies')}
            </p>
        </div>
    </div>
    <div style="margin-top: 1.5rem; padding: 1rem; background: #f0fdf4; border-radius: 0.75rem; border-left: 4px solid #10b981;">
        <strong style="color: #166534;">Recommendation:</strong>
        <p style="margin-top: 0.5rem; color: var(--text-muted);">
            {comparison.get('recommendation', 'Use multiples as floor, Bottom-Up Beta for DCF ceiling.')}
        </p>
    </div>
</div>'''

    def _build_expectations_section(self, startup_table: list) -> str:
        """Build expectations analysis section - Multiple valuation thresholds."""
        cards = ""
        for row in startup_table:
            current_growth = row.get('current_growth_pct', 0)
            current_multiple = row.get('current_multiple', 0)
            thresholds = row.get('thresholds', [])
            verdict_status = row.get('verdict_status', 'unknown')
            verdict_color = row.get('verdict_color', '#6b7280')
            verdict_message = row.get('verdict_message', '')
            verdict_recommendation = row.get('verdict_recommendation', '')
            projected_y5 = row.get('projected_y5_valuation', 'N/A')

            # Format verdict display
            verdict_display = verdict_status.replace('_', ' ').title()

            # Build threshold rows
            threshold_rows = ""
            for i, t in enumerate(thresholds):
                target = t.get('target', 'N/A')
                required_cagr = t.get('required_cagr', 0)
                probability = t.get('probability', 0)
                prob_rating = t.get('probability_rating', 'N/A')
                difficulty = t.get('difficulty', 'N/A')
                is_upside = t.get('is_upside', True)

                # Determine row class based on difficulty
                if probability >= 50:
                    row_class = "upside"
                elif probability >= 20:
                    row_class = "stretch"
                else:
                    row_class = "aggressive"

                # Probability dot class
                if probability >= 50:
                    prob_dot_class = "high"
                elif probability >= 30:
                    prob_dot_class = "moderate"
                elif probability >= 15:
                    prob_dot_class = "low"
                else:
                    prob_dot_class = "very-low"

                # Difficulty badge class based on keywords in difficulty string
                diff_lower = difficulty.lower() if difficulty else ""
                if "easy" in diff_lower or "exceeds" in diff_lower:
                    diff_class = "achievable"
                elif "moderate" in diff_lower or "maintain" in diff_lower:
                    diff_class = "challenging"
                elif "difficult" in diff_lower or "significant" in diff_lower:
                    diff_class = "aggressive"
                else:
                    diff_class = "extreme"

                threshold_rows += f'''
                <tr class="threshold-row {row_class}">
                    <td><strong>{target}</strong></td>
                    <td style="color: var(--accent-purple); font-weight: 600;">{required_cagr:.0f}%</td>
                    <td>
                        <span class="prob-indicator">
                            <span class="prob-dot {prob_dot_class}"></span>
                            <span>{probability:.0f}%</span>
                        </span>
                    </td>
                    <td><span class="difficulty-badge difficulty-{diff_class}">{difficulty}</span></td>
                </tr>'''

            cards += f'''
            <div class="threshold-card">
                <div class="threshold-header">
                    <span class="threshold-company">{row.get('name', 'Unknown')}</span>
                    <span class="verdict-badge" style="background: {verdict_color}; color: white;">{verdict_display}</span>
                </div>
                <div class="threshold-meta">
                    <span>Current Growth: <strong style="color: var(--primary-blue);">{current_growth:.0f}%</strong></span>
                    <span>Current Multiple: <strong>{current_multiple:.1f}x</strong></span>
                    <span>Projected Y5: <strong style="color: var(--accent-purple);">{projected_y5}</strong></span>
                </div>
                <table class="threshold-table">
                    <thead>
                        <tr>
                            <th>Target Valuation</th>
                            <th>Required CAGR</th>
                            <th>Probability</th>
                            <th>Difficulty</th>
                        </tr>
                    </thead>
                    <tbody>
                        {threshold_rows}
                    </tbody>
                </table>
                <div style="margin-top: 0.75rem; padding: 0.75rem; background: var(--bg-light); border-radius: 0.5rem; font-size: 0.85rem;">
                    <div style="color: var(--text-dark);"><strong>Assessment:</strong> {verdict_message}</div>
                    <div style="color: var(--text-muted); margin-top: 0.25rem;">{verdict_recommendation}</div>
                </div>
            </div>'''

        return f'''
<div class="section" style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);">
    <h2>Expectations Analysis: Valuation Thresholds</h2>
    <p style="color: var(--text-muted); margin-bottom: 1rem;">
        For each startup, we analyze the growth required to reach different valuation milestones,
        along with the probability of achieving each target based on current momentum.
    </p>

    <div style="display: flex; gap: 2rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span class="prob-dot high"></span>
            <span style="font-size: 0.85rem;">High Probability (&gt;50%)</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span class="prob-dot moderate"></span>
            <span style="font-size: 0.85rem;">Moderate (30-50%)</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span class="prob-dot low"></span>
            <span style="font-size: 0.85rem;">Low (15-30%)</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span class="prob-dot very-low"></span>
            <span style="font-size: 0.85rem;">Very Low (&lt;15%)</span>
        </div>
    </div>

    {cards}

    <div style="margin-top: 1.5rem; padding: 1rem; background: white; border-radius: 0.75rem;">
        <h4 style="margin-bottom: 0.75rem; color: var(--text-dark);">How to Read This</h4>
        <ul style="margin-left: 1.5rem; font-size: 0.9rem; color: var(--text-muted);">
            <li><strong>Target Valuation:</strong> Key milestone valuations (e.g., $50B, $100B, $500B)</li>
            <li><strong>Required CAGR:</strong> The annual revenue growth needed over 5 years to reach that target at a 10x exit multiple</li>
            <li><strong>Probability:</strong> Likelihood of reaching the target based on current growth trajectory and typical growth decay patterns</li>
            <li><strong>Difficulty Rating:</strong> Achievable (growing faster than needed), Challenging (need to maintain), Aggressive (need to accelerate), Extreme (requires exceptional performance)</li>
        </ul>
    </div>
</div>'''

    def _build_sensitivity_section(self, scenarios: Dict) -> str:
        """Build interactive sensitivity analysis section."""
        # Get startup options
        startup_options = ""
        for startup_id, startup_data in scenarios.get("startup_scenarios", {}).items():
            name = startup_data.get("startup_info", {}).get("name", startup_id)
            startup_options += f'<option value="{startup_id}">{name}</option>'

        # Get peer scenario options
        peer_options = ""
        for scenario_id, scenario_config in PEER_SCENARIOS.items():
            peer_options += f'<option value="{scenario_id}">{scenario_config["name"]}</option>'

        return f'''
<div class="section scenario-section">
    <h2>Sensitivity Analysis: Peer Selection Impact</h2>
    <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
        Explore how different peer group selections affect valuation results.
    </p>
    <div class="scenario-controls">
        <select id="startup-select" class="scenario-select" onchange="updateScenario()">
            {startup_options}
        </select>
        <select id="peer-select" class="scenario-select" onchange="updateScenario()">
            <option value="default">Default Peers</option>
            {peer_options}
        </select>
    </div>
    <div class="scenario-results" id="scenario-results">
        <p style="color: var(--text-muted);">Select a startup and peer scenario to see results.</p>
    </div>
</div>'''

    def _build_conclusions(self, comparison: Dict) -> str:
        """Build conclusions section."""
        return '''
<div class="section">
    <h2>Key Conclusions</h2>
    <ul class="conclusions-list">
        <li>
            <strong>Trading Multiples Systematically Undervalue:</strong>
            Across all 8 AI startups, peer-based multiples undervalue by 2.7x to 38x.
            This approach fails to capture growth optionality and strategic value.
        </li>
        <li>
            <strong>Bottom-Up Beta Provides Consistency:</strong>
            Cost of Equity calculations land in the 17-20% range for most companies,
            providing a stable foundation for DCF analysis regardless of growth rate.
        </li>
        <li>
            <strong>Gap Correlates with Growth and Strategic Value:</strong>
            Higher growth rates and strategic acquisitions show larger gaps.
            xAI (38x) and Perplexity (18x) represent outliers with unique strategic positioning.
        </li>
        <li>
            <strong>Practical Recommendation:</strong>
            Use multiples as a valuation floor, then apply Bottom-Up Beta in a DCF
            to find the ceiling. The true value lies in the range between them.
        </li>
    </ul>
</div>'''

    def _build_data_sources(self, results: Dict) -> str:
        """Build data sources section."""
        timestamp = results.get("summary", {}).get("timestamp", datetime.now().isoformat())

        return f'''
<div style="text-align: center; margin-top: 2rem; padding: 1.5rem; background: #f8fafc; border-radius: 0.5rem;">
    <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 0.5rem;">
        <strong>Data Sources</strong>
    </p>
    <span style="background: #e0f2fe; padding: 0.25rem 0.75rem; border-radius: 1rem; margin: 0.25rem; display: inline-block; font-size: 0.85rem;">Yahoo Finance</span>
    <span style="background: #e0f2fe; padding: 0.25rem 0.75rem; border-radius: 1rem; margin: 0.25rem; display: inline-block; font-size: 0.85rem;">TechCrunch</span>
    <span style="background: #e0f2fe; padding: 0.25rem 0.75rem; border-radius: 1rem; margin: 0.25rem; display: inline-block; font-size: 0.85rem;">Bloomberg</span>
    <span style="background: #e0f2fe; padding: 0.25rem 0.75rem; border-radius: 1rem; margin: 0.25rem; display: inline-block; font-size: 0.85rem;">Sacra</span>
    <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 1rem;">
        Last updated: {timestamp[:10]}
    </p>
</div>'''

    def _get_javascript(self, scenarios: Dict) -> str:
        """Return JavaScript for interactivity."""
        scenarios_json = json.dumps(scenarios.get("startup_scenarios", {}), default=str)

        return f'''
const scenarioData = {scenarios_json};

function updateScenario() {{
    const startupId = document.getElementById('startup-select').value;
    const peerId = document.getElementById('peer-select').value;

    const startupData = scenarioData[startupId];
    if (!startupData) {{
        document.getElementById('scenario-results').innerHTML =
            '<p style="color: var(--text-muted);">No data available for this selection.</p>';
        return;
    }}

    const scenario = startupData.scenarios[peerId] || startupData.scenarios['default'];
    if (!scenario || !scenario.success) {{
        document.getElementById('scenario-results').innerHTML =
            '<p style="color: var(--danger-red);">Error loading scenario data.</p>';
        return;
    }}

    const a1 = scenario.approach_1;
    const a2 = scenario.approach_2;
    const info = startupData.startup_info;

    const html = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <div>
                <h4 style="color: var(--accent-orange); margin-bottom: 0.5rem;">Trading Multiples</h4>
                <p><strong>Peer Multiple:</strong> ${{a1.peer_multiple.toFixed(1)}}x EV/Revenue</p>
                <p><strong>Implied Valuation:</strong> ${{a1.implied_valuation_display}}</p>
                <p><strong>Gap vs Actual:</strong> <span style="color: var(--danger-red); font-weight: bold;">${{a1.gap_display}}</span></p>
            </div>
            <div>
                <h4 style="color: var(--accent-purple); margin-bottom: 0.5rem;">Bottom-Up Beta</h4>
                <p><strong>Relevered Beta:</strong> ${{a2.relevered_beta.toFixed(2)}}</p>
                <p><strong>Size Premium:</strong> ${{a2.size_premium_pct.toFixed(1)}}%</p>
                <p><strong>Cost of Equity:</strong> <span style="color: var(--accent-purple); font-weight: bold;">${{a2.coe_display}}</span></p>
            </div>
        </div>
        <div style="margin-top: 1rem; padding: 0.75rem; background: var(--bg-light); border-radius: 0.5rem;">
            <strong>Peers Used:</strong> ${{scenario.peers.join(', ')}}
        </div>
    `;

    document.getElementById('scenario-results').innerHTML = html;
}}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {{
    updateScenario();
}});
'''
