"""
Valuation Engine

Implements two valuation approaches:
1. Trading Multiples (EV/Revenue)
2. Bottom-Up Beta (CAPM + Size Premium)
"""

from typing import Dict, Optional
from .config import VALUATION_PARAMS, DEAL_TYPES, get_revenue, get_size_premium, get_dlom


class ValuationEngine:
    """
    Core valuation calculations for private companies.

    Implements:
    - Approach 1: Trading Multiples (relative valuation)
    - Approach 2: Bottom-Up Beta (income approach via CAPM)
    """

    def __init__(self, params: Dict = None):
        """
        Initialize the valuation engine.

        Args:
            params: Valuation parameters (defaults to VALUATION_PARAMS)
        """
        self.params = params or VALUATION_PARAMS

    # =========================================================================
    # APPROACH 1: TRADING MULTIPLES
    # =========================================================================

    def approach_1_trading_multiples(
        self,
        startup: Dict,
        peer_stats: Dict,
        apply_dlom: bool = True
    ) -> Dict:
        """
        Calculate valuation using peer EV/Revenue multiples.

        This is the "Relative Valuation" or "Market Approach":
        - Uses median EV/Revenue from public comparables
        - Applies DLOM (Discount for Lack of Marketability) for private companies

        Args:
            startup: Startup data dictionary
            peer_stats: Peer group statistics (from PeerDataFetcher)
            apply_dlom: Whether to apply DLOM discount

        Returns:
            Dictionary with valuation results
        """
        # Get revenue/ARR
        revenue = get_revenue(startup)
        if revenue <= 0:
            return {
                "method": "trading_multiples",
                "error": "No revenue data available",
                "implied_valuation": 0
            }

        # Get peer multiple
        median_multiple = peer_stats.get("median_ev_revenue", 0)
        if median_multiple <= 0:
            return {
                "method": "trading_multiples",
                "error": "No valid peer multiples",
                "implied_valuation": 0
            }

        # Calculate implied enterprise value
        implied_ev = revenue * median_multiple

        # Apply DLOM if requested
        dlom = get_dlom(startup) if apply_dlom else 0
        implied_ev_after_dlom = implied_ev * (1 - dlom)

        # Compare to actual valuation
        actual_valuation = startup.get("valuation", 0)
        gap = actual_valuation / implied_ev_after_dlom if implied_ev_after_dlom > 0 else float('inf')
        gap_before_dlom = actual_valuation / implied_ev if implied_ev > 0 else float('inf')

        # Implied multiple (what market is actually paying)
        implied_market_multiple = actual_valuation / revenue if revenue > 0 else 0

        return {
            "method": "trading_multiples",

            # Inputs
            "revenue_used": revenue,
            "peer_median_multiple": median_multiple,
            "peers_used": peer_stats.get("peers_used", []),
            "peer_count": peer_stats.get("count", 0),

            # DLOM
            "dlom_applied": apply_dlom,
            "dlom_rate": dlom,

            # Outputs
            "implied_ev_before_dlom": implied_ev,
            "implied_valuation": implied_ev_after_dlom,

            # Comparison to actual
            "actual_valuation": actual_valuation,
            "gap": round(gap, 2),
            "gap_before_dlom": round(gap_before_dlom, 2),
            "undervaluation_factor": round(gap, 2),

            # Market-implied multiple
            "implied_market_multiple": round(implied_market_multiple, 1),
            "multiple_premium_pct": round((implied_market_multiple / median_multiple - 1) * 100, 1) if median_multiple > 0 else 0,

            # Interpretation
            "interpretation": self._interpret_gap(gap)
        }

    def _interpret_gap(self, gap: float) -> str:
        """Provide interpretation of the valuation gap."""
        if gap < 1.5:
            return "Close to peer multiples - standard VC pricing"
        elif gap < 3:
            return "Moderate premium - growth expectations embedded"
        elif gap < 7:
            return "Significant premium - strategic value or exceptional growth"
        elif gap < 20:
            return "Large premium - market leader or unique asset"
        else:
            return "Extreme premium - speculative or strategic acquisition"

    # =========================================================================
    # APPROACH 2: BOTTOM-UP BETA (CAPM)
    # =========================================================================

    def approach_2_bottom_up_beta(
        self,
        startup: Dict,
        peer_stats: Dict
    ) -> Dict:
        """
        Calculate Cost of Equity using CAPM with Bottom-Up Beta.

        This is the "Income Approach" foundation:
        - Uses unlevered beta from public comparables
        - Re-levers for target capital structure
        - Applies CAPM with size premium

        Formula: Ke = Rf + β × ERP + Size Premium

        Args:
            startup: Startup data dictionary
            peer_stats: Peer group statistics (from PeerDataFetcher)

        Returns:
            Dictionary with Cost of Equity and supporting calculations
        """
        # Get median unlevered beta from peers
        unlevered_beta = peer_stats.get("median_unlevered_beta", 1.0)

        # Target capital structure (most VC-backed startups have 0 debt)
        target_de_ratio = startup.get("de_ratio_pct", 0)

        # Re-lever beta for target
        relevered_beta = self._relever_beta(unlevered_beta, target_de_ratio)

        # Get CAPM inputs
        rf = self.params["risk_free_rate"]
        erp = self.params["equity_risk_premium"]
        size_premium = get_size_premium(startup)

        # Calculate Cost of Equity
        cost_of_equity = rf + (relevered_beta * erp) + size_premium

        # Calculate implied metrics
        revenue = get_revenue(startup)
        actual_valuation = startup.get("valuation", 0)
        growth_rate = startup.get("growth_rate_pct", 0) / 100

        # Implied annual return required
        implied_annual_return = actual_valuation * cost_of_equity

        # What FCF margin is needed at maturity to justify valuation?
        # Simplified: Assuming perpetuity growth model at maturity
        terminal_growth = 0.03  # 3% terminal growth
        if cost_of_equity > terminal_growth:
            implied_terminal_fcf = actual_valuation * (cost_of_equity - terminal_growth)
        else:
            implied_terminal_fcf = 0

        return {
            "method": "bottom_up_beta",

            # Peer data
            "peer_median_unlevered_beta": unlevered_beta,
            "peer_median_levered_beta": peer_stats.get("median_beta", 1.0),
            "peers_used": peer_stats.get("peers_used", []),
            "peer_count": peer_stats.get("count", 0),

            # Target company
            "target_de_ratio_pct": target_de_ratio,
            "relevered_beta": round(relevered_beta, 3),

            # CAPM components
            "risk_free_rate": rf,
            "risk_free_rate_pct": round(rf * 100, 2),
            "equity_risk_premium": erp,
            "equity_risk_premium_pct": round(erp * 100, 2),
            "size_premium": size_premium,
            "size_premium_pct": round(size_premium * 100, 2),

            # Result
            "cost_of_equity": cost_of_equity,
            "cost_of_equity_pct": round(cost_of_equity * 100, 2),

            # Implied requirements
            "actual_valuation": actual_valuation,
            "implied_annual_return": implied_annual_return,
            "implied_terminal_fcf": implied_terminal_fcf,

            # Context
            "revenue": revenue,
            "growth_rate_pct": startup.get("growth_rate_pct", 0),

            # Interpretation
            "interpretation": self._interpret_coe(cost_of_equity),
            "reasonableness": self._assess_coe_reasonableness(cost_of_equity)
        }

    def _relever_beta(self, unlevered_beta: float, target_de_ratio_pct: float) -> float:
        """
        Re-lever beta for target capital structure.

        Formula: β_T = β_u × [1 + (1-T) × (D/E)]
        """
        tax_rate = self.params["tax_rate"]
        de_ratio = target_de_ratio_pct / 100

        return unlevered_beta * (1 + (1 - tax_rate) * de_ratio)

    def _interpret_coe(self, coe: float) -> str:
        """Provide interpretation of Cost of Equity."""
        if coe < 0.12:
            return "Low risk - unusual for private companies"
        elif coe < 0.16:
            return "Moderate risk - mature, stable business"
        elif coe < 0.20:
            return "Standard for growth-stage startups"
        elif coe < 0.25:
            return "High risk - early-stage or volatile"
        else:
            return "Very high risk - pre-revenue or speculative"

    def _assess_coe_reasonableness(self, coe: float) -> Dict:
        """Assess if Cost of Equity is in reasonable range."""
        return {
            "is_reasonable": 0.15 <= coe <= 0.25,
            "min_reasonable": 0.15,
            "max_reasonable": 0.25,
            "status": "within_range" if 0.15 <= coe <= 0.25 else
                     "below_range" if coe < 0.15 else "above_range"
        }

    # =========================================================================
    # COMBINED ANALYSIS
    # =========================================================================

    def run_both_approaches(
        self,
        startup: Dict,
        peer_stats: Dict,
        apply_dlom: bool = True
    ) -> Dict:
        """
        Run both valuation approaches and compare results.

        Args:
            startup: Startup data dictionary
            peer_stats: Peer group statistics
            apply_dlom: Whether to apply DLOM in Approach 1

        Returns:
            Combined results with comparison
        """
        approach_1 = self.approach_1_trading_multiples(startup, peer_stats, apply_dlom)
        approach_2 = self.approach_2_bottom_up_beta(startup, peer_stats)

        return {
            "startup_name": startup.get("name", "Unknown"),
            "approach_1": approach_1,
            "approach_2": approach_2,
            "comparison": self._compare_approaches(approach_1, approach_2)
        }

    def _compare_approaches(self, approach_1: Dict, approach_2: Dict) -> Dict:
        """Compare results from both approaches."""
        gap = approach_1.get("gap", 0)
        coe = approach_2.get("cost_of_equity_pct", 0)
        coe_reasonable = approach_2.get("reasonableness", {}).get("is_reasonable", False)

        # Determine which approach provides more insight
        if gap > 3 and coe_reasonable:
            recommendation = "bottom_up_beta"
            reason = f"Gap of {gap:.1f}x suggests multiples undervalue; CoE of {coe:.1f}% provides better risk-adjusted framework"
        elif gap <= 2:
            recommendation = "trading_multiples"
            reason = f"Gap of {gap:.1f}x suggests multiples are reasonable; standard comp analysis applies"
        else:
            recommendation = "both"
            reason = f"Moderate gap of {gap:.1f}x; use multiples as floor, DCF with {coe:.1f}% CoE for ceiling"

        return {
            "gap": gap,
            "cost_of_equity_pct": coe,
            "multiples_undervalue": gap > 2,
            "coe_is_reasonable": coe_reasonable,
            "recommended_approach": recommendation,
            "recommendation_reason": reason
        }

    # =========================================================================
    # EXPECTATIONS ANALYSIS (Current vs Required Speed)
    # =========================================================================

    def expectations_analysis(
        self,
        startup: Dict,
        cost_of_equity: float,
        projection_years: int = 5
    ) -> Dict:
        """
        Analyze what growth is needed to reach various valuation thresholds.

        Key questions answered:
        - What CAGR needed to reach $X billion valuation?
        - How does current growth compare to required growth for each threshold?
        - What's the probability of reaching each threshold?

        Args:
            startup: Startup data dictionary
            cost_of_equity: Cost of Equity from Approach 2
            projection_years: Years to project forward

        Returns:
            Dictionary with expectations analysis
        """
        revenue = get_revenue(startup)
        valuation = startup.get("valuation", 0)
        current_growth = startup.get("growth_rate_pct", 0) / 100  # Convert to decimal

        if revenue <= 0 or valuation <= 0:
            return {"error": "Missing revenue or valuation data"}

        # Current implied multiple
        current_multiple = valuation / revenue

        # Define valuation thresholds based on company size
        thresholds = self._get_valuation_thresholds(valuation)

        # Calculate required growth for each threshold
        threshold_analysis = self._analyze_thresholds(
            revenue=revenue,
            current_valuation=valuation,
            current_growth=current_growth,
            cost_of_equity=cost_of_equity,
            thresholds=thresholds,
            projection_years=projection_years
        )

        # Build trajectory projections at current growth
        current_trajectory = self._build_trajectory(
            revenue, current_growth, projection_years
        )

        # Projected valuation at current growth (using current multiple decay)
        projected_valuation = self._project_valuation(
            revenue, current_growth, current_multiple, projection_years
        )

        # Overall verdict based on threshold analysis
        verdict = self._determine_threshold_verdict(
            current_growth, threshold_analysis, valuation
        )

        return {
            "current_metrics": {
                "revenue": revenue,
                "revenue_display": self._format_currency(revenue),
                "valuation": valuation,
                "valuation_display": self._format_currency(valuation),
                "current_multiple": round(current_multiple, 1),
                "current_growth_rate_pct": round(current_growth * 100, 1)
            },

            "projection_params": {
                "projection_years": projection_years,
                "cost_of_equity_pct": round(cost_of_equity * 100, 1),
                "exit_multiple_assumed": 10  # For reference
            },

            "current_trajectory": current_trajectory,
            "projected_valuation": projected_valuation,

            "valuation_thresholds": threshold_analysis,

            "verdict": verdict
        }

    def _get_valuation_thresholds(self, current_valuation: float) -> Dict:
        """
        Generate appropriate valuation thresholds based on current size.

        Small companies: $1B, $5B, $10B, $25B
        Medium companies: $10B, $25B, $50B, $100B
        Large companies: $50B, $100B, $250B, $500B
        Mega companies: $100B, $250B, $500B, $1T
        """
        if current_valuation < 5e9:  # < $5B
            return {
                "threshold_1": 5e9,      # $5B
                "threshold_2": 10e9,     # $10B
                "threshold_3": 25e9,     # $25B
                "threshold_4": 50e9      # $50B
            }
        elif current_valuation < 25e9:  # $5B - $25B
            return {
                "threshold_1": 25e9,     # $25B
                "threshold_2": 50e9,     # $50B
                "threshold_3": 100e9,    # $100B
                "threshold_4": 200e9     # $200B
            }
        elif current_valuation < 100e9:  # $25B - $100B
            return {
                "threshold_1": 100e9,    # $100B
                "threshold_2": 200e9,    # $200B
                "threshold_3": 350e9,    # $350B
                "threshold_4": 500e9     # $500B
            }
        else:  # > $100B
            return {
                "threshold_1": 250e9,    # $250B
                "threshold_2": 500e9,    # $500B
                "threshold_3": 750e9,    # $750B
                "threshold_4": 1e12      # $1T
            }

    def _analyze_thresholds(
        self,
        revenue: float,
        current_valuation: float,
        current_growth: float,
        cost_of_equity: float,
        thresholds: Dict,
        projection_years: int
    ) -> Dict:
        """
        Calculate required growth and probability for each valuation threshold.

        Uses DCF methodology:
        - Target valuation is the present value we want to achieve
        - Terminal value is calculated using Gordon Growth Model
        - Cost of Equity is the discount rate
        - Terminal FCF margin assumed at 20% for mature companies

        DCF Formula:
        PV = Σ(FCF_t / (1+r)^t) + TV / (1+r)^n
        TV = FCF_n × (1+g) / (r-g)  [Gordon Growth Model]
        """
        terminal_growth = 0.03  # 3% terminal growth rate
        terminal_fcf_margin = 0.20  # 20% FCF margin at maturity

        results = {}
        for threshold_name, target_valuation in thresholds.items():
            # Step 1: Work backwards from target valuation using DCF
            # Assume terminal value is ~60% of total enterprise value (typical for growth companies)
            terminal_value_weight = 0.60
            terminal_value_pv = target_valuation * terminal_value_weight

            # Step 2: Calculate terminal value (future value)
            # PV of TV = TV / (1+r)^n  →  TV = PV × (1+r)^n
            terminal_value = terminal_value_pv * (1 + cost_of_equity) ** projection_years

            # Step 3: Calculate terminal FCF using Gordon Growth
            # TV = FCF × (1+g) / (r-g)  →  FCF = TV × (r-g) / (1+g)
            if cost_of_equity > terminal_growth:
                terminal_fcf = terminal_value * (cost_of_equity - terminal_growth) / (1 + terminal_growth)
            else:
                # Edge case: use simple capitalization if CoE <= terminal growth
                terminal_fcf = terminal_value / 20  # 20x FCF multiple

            # Step 4: Calculate required terminal revenue
            # FCF = Revenue × FCF_Margin  →  Revenue = FCF / FCF_Margin
            required_terminal_revenue = terminal_fcf / terminal_fcf_margin

            # Step 5: Calculate required CAGR
            if revenue > 0 and required_terminal_revenue > revenue:
                required_cagr = (required_terminal_revenue / revenue) ** (1 / projection_years) - 1
            else:
                required_cagr = 0

            # Growth gap
            growth_gap = required_cagr - current_growth

            # Probability of reaching this threshold
            probability = self._calculate_threshold_probability(
                current_growth, required_cagr, current_valuation, target_valuation
            )

            # Difficulty rating
            difficulty = self._rate_difficulty(current_growth, required_cagr)

            # Is it above or below current valuation?
            is_upside = target_valuation > current_valuation
            multiple_of_current = target_valuation / current_valuation if current_valuation > 0 else 0

            # Calculate implied revenue multiple at terminal
            implied_terminal_multiple = terminal_value / required_terminal_revenue if required_terminal_revenue > 0 else 0

            results[threshold_name] = {
                "target_valuation": target_valuation,
                "target_display": self._format_currency(target_valuation),
                "required_terminal_revenue": round(required_terminal_revenue, 0),
                "required_revenue_display": self._format_currency(required_terminal_revenue),
                "required_terminal_fcf": round(terminal_fcf, 0),
                "required_terminal_fcf_display": self._format_currency(terminal_fcf),
                "implied_terminal_multiple": round(implied_terminal_multiple, 1),
                "required_cagr_pct": round(required_cagr * 100, 1),
                "current_growth_pct": round(current_growth * 100, 1),
                "growth_gap_pct": round(growth_gap * 100, 1),
                "probability_pct": round(probability * 100, 0),
                "probability_rating": self._rate_probability(probability),
                "difficulty": difficulty,
                "is_upside": is_upside,
                "multiple_of_current": round(multiple_of_current, 2),
                # DCF parameters used
                "dcf_params": {
                    "cost_of_equity_pct": round(cost_of_equity * 100, 1),
                    "terminal_growth_pct": round(terminal_growth * 100, 1),
                    "terminal_fcf_margin_pct": round(terminal_fcf_margin * 100, 0),
                    "terminal_value_weight_pct": round(terminal_value_weight * 100, 0)
                }
            }

        return results

    def _calculate_threshold_probability(
        self,
        current_growth: float,
        required_growth: float,
        current_valuation: float,
        target_valuation: float
    ) -> float:
        """
        Calculate probability of reaching a valuation threshold.

        Model based on:
        1. Growth sustainability (can current growth continue?)
        2. Gap between current and required growth
        3. Historical startup success rates at different thresholds
        """
        if required_growth <= 0:
            return 0.90  # Already there

        # Base probability from growth comparison
        if current_growth >= required_growth:
            # Current growth exceeds required - high probability
            excess = current_growth - required_growth
            base_prob = min(0.85, 0.65 + excess * 1.5)
        elif current_growth >= required_growth * 0.8:
            # Close to required - moderate probability
            base_prob = 0.45 + (current_growth / required_growth - 0.8) * 1.5
        elif current_growth >= required_growth * 0.5:
            # Significant gap - lower probability
            base_prob = 0.20 + (current_growth / required_growth - 0.5) * 0.8
        else:
            # Large gap - low probability
            ratio = current_growth / required_growth if required_growth > 0 else 0
            base_prob = max(0.05, ratio * 0.4)

        # Adjust for target size (harder to reach very large valuations)
        if target_valuation > 500e9:  # > $500B
            size_penalty = 0.85
        elif target_valuation > 200e9:  # > $200B
            size_penalty = 0.90
        elif target_valuation > 100e9:  # > $100B
            size_penalty = 0.95
        else:
            size_penalty = 1.0

        return min(0.90, base_prob * size_penalty)

    def _build_trajectory(
        self,
        revenue: float,
        growth_rate: float,
        years: int
    ) -> list:
        """Build revenue trajectory at given growth rate."""
        trajectory = []
        for year in range(years + 1):
            rev = revenue * (1 + growth_rate) ** year
            trajectory.append({
                "year": year,
                "revenue": round(rev, 0),
                "revenue_display": self._format_currency(rev)
            })
        return trajectory

    def _project_valuation(
        self,
        revenue: float,
        growth_rate: float,
        current_multiple: float,
        years: int
    ) -> Dict:
        """
        Project valuation assuming multiple compression as company matures.

        Multiple decay: High-growth multiples compress toward 10x as growth slows.
        """
        # Terminal multiple (assume convergence to 10x over time)
        terminal_multiple = 10
        multiple_decay_per_year = (current_multiple - terminal_multiple) / years if years > 0 else 0

        projections = []
        for year in range(years + 1):
            rev = revenue * (1 + growth_rate) ** year
            # Multiple decays linearly toward terminal
            multiple = max(terminal_multiple, current_multiple - (multiple_decay_per_year * year))
            val = rev * multiple

            projections.append({
                "year": year,
                "revenue": round(rev, 0),
                "revenue_display": self._format_currency(rev),
                "multiple": round(multiple, 1),
                "valuation": round(val, 0),
                "valuation_display": self._format_currency(val)
            })

        return {
            "projections": projections,
            "year_5_valuation": projections[-1]["valuation"],
            "year_5_valuation_display": projections[-1]["valuation_display"]
        }

    def _determine_threshold_verdict(
        self,
        current_growth: float,
        threshold_analysis: Dict,
        current_valuation: float
    ) -> Dict:
        """Determine overall verdict based on threshold analysis."""
        # Find the first threshold above current valuation
        first_upside = None
        for key, data in threshold_analysis.items():
            if data["is_upside"] and (first_upside is None or data["target_valuation"] < threshold_analysis[first_upside]["target_valuation"]):
                first_upside = key

        if first_upside is None:
            return {
                "status": "at_ceiling",
                "color": "#6b7280",
                "message": "Already at or above analyzed thresholds.",
                "recommendation": "Consider higher threshold analysis."
            }

        first_data = threshold_analysis[first_upside]
        prob = first_data["probability_pct"]
        required = first_data["required_cagr_pct"]
        target = first_data["target_display"]

        if prob >= 60:
            return {
                "status": "on_track",
                "color": "#10b981",
                "message": f"Current growth supports reaching {target} ({prob:.0f}% probability).",
                "recommendation": f"Growth of {current_growth*100:.0f}% exceeds or matches required {required:.0f}%."
            }
        elif prob >= 35:
            return {
                "status": "achievable",
                "color": "#f59e0b",
                "message": f"Reaching {target} is achievable but requires sustained execution ({prob:.0f}% probability).",
                "recommendation": f"Need {required:.0f}% CAGR vs current {current_growth*100:.0f}%."
            }
        elif prob >= 15:
            return {
                "status": "stretch",
                "color": "#f97316",
                "message": f"Reaching {target} is a stretch goal ({prob:.0f}% probability).",
                "recommendation": f"Significant acceleration needed: {required:.0f}% vs {current_growth*100:.0f}%."
            }
        else:
            return {
                "status": "unlikely",
                "color": "#ef4444",
                "message": f"Reaching {target} is unlikely at current trajectory ({prob:.0f}% probability).",
                "recommendation": f"Would require {required:.0f}% CAGR, far above current {current_growth*100:.0f}%."
            }

    def _rate_difficulty(self, current_growth: float, required_growth: float) -> str:
        """Rate the difficulty of achieving required growth."""
        if required_growth <= 0:
            return "N/A"

        ratio = current_growth / required_growth

        if ratio >= 1.2:
            return "Easy - Current growth exceeds requirements"
        elif ratio >= 1.0:
            return "Achievable - Current growth meets requirements"
        elif ratio >= 0.7:
            return "Moderate - Needs some acceleration"
        elif ratio >= 0.5:
            return "Difficult - Significant acceleration needed"
        else:
            return "Very Difficult - Exceptional acceleration required"

    def _rate_probability(self, prob: float) -> str:
        """Convert probability to rating."""
        if prob >= 0.7:
            return "High"
        elif prob >= 0.4:
            return "Moderate"
        elif prob >= 0.2:
            return "Low"
        else:
            return "Very Low"

    def _determine_expectations_verdict(
        self,
        current_growth: float,
        implied_cagr: float,
        growth_gap: float
    ) -> Dict:
        """Determine overall verdict on valuation expectations."""
        if implied_cagr <= 0:
            return {
                "status": "undefined",
                "message": "Unable to calculate implied growth"
            }

        ratio = current_growth / implied_cagr

        if ratio >= 1.2:
            return {
                "status": "undervalued",
                "color": "#10b981",
                "message": f"Current growth ({current_growth*100:.0f}%) exceeds required ({implied_cagr*100:.0f}%). Valuation may be conservative.",
                "recommendation": "Consider upside scenarios - current trajectory supports higher valuation."
            }
        elif ratio >= 0.9:
            return {
                "status": "fairly_valued",
                "color": "#f59e0b",
                "message": f"Current growth ({current_growth*100:.0f}%) roughly matches required ({implied_cagr*100:.0f}%). Valuation reflects expectations.",
                "recommendation": "Valuation assumes growth continues at current pace. Monitor for deceleration."
            }
        elif ratio >= 0.6:
            return {
                "status": "growth_dependent",
                "color": "#f97316",
                "message": f"Current growth ({current_growth*100:.0f}%) below required ({implied_cagr*100:.0f}%). Valuation assumes acceleration.",
                "recommendation": "Valuation embeds significant growth expectations. High execution risk."
            }
        else:
            return {
                "status": "overvalued_risk",
                "color": "#ef4444",
                "message": f"Current growth ({current_growth*100:.0f}%) far below required ({implied_cagr*100:.0f}%). Valuation highly speculative.",
                "recommendation": "Extreme growth acceleration priced in. Consider downside scenarios."
            }

    def _format_currency(self, value: float) -> str:
        """Format currency value for display."""
        if value >= 1e12:
            return f"${value/1e12:.1f}T"
        elif value >= 1e9:
            return f"${value/1e9:.1f}B"
        elif value >= 1e6:
            return f"${value/1e6:.0f}M"
        else:
            return f"${value:,.0f}"

    # =========================================================================
    # DCF HELPER
    # =========================================================================

    def calculate_dcf_required_fcf(
        self,
        target_valuation: float,
        cost_of_equity: float,
        years: int = 10,
        terminal_growth: float = 0.03,
        growth_decay_rate: float = 0.15
    ) -> Dict:
        """
        Calculate the FCF trajectory required to justify a valuation.

        This is a reverse-DCF: given valuation and CoE, what FCF is needed?

        Args:
            target_valuation: Target valuation to justify
            cost_of_equity: Discount rate
            years: Projection period
            terminal_growth: Terminal growth rate (default 3%)
            growth_decay_rate: How fast growth decays each year

        Returns:
            Dictionary with required FCF trajectory
        """
        # Terminal value multiple
        terminal_multiple = 1 / (cost_of_equity - terminal_growth) if cost_of_equity > terminal_growth else 20

        # Work backwards from terminal value
        # Terminal value = terminal_multiple * terminal_fcf
        # PV of terminal = terminal_value / (1 + r)^n

        # Simplified: assume terminal value is ~50% of total value
        terminal_value_pv = target_valuation * 0.5
        terminal_value = terminal_value_pv * (1 + cost_of_equity) ** years
        terminal_fcf = terminal_value / terminal_multiple

        # Calculate FCF needed in each year (growing from year 1 to terminal)
        fcf_trajectory = []
        year_1_fcf = terminal_fcf / ((1 + terminal_growth) ** (years - 1))

        for year in range(1, years + 1):
            if year == years:
                fcf = terminal_fcf
            else:
                # Exponential growth to terminal
                fcf = year_1_fcf * ((terminal_fcf / year_1_fcf) ** (year / years))
            fcf_trajectory.append({
                "year": year,
                "fcf": round(fcf, 0),
                "pv_factor": round(1 / (1 + cost_of_equity) ** year, 4),
                "pv_fcf": round(fcf / (1 + cost_of_equity) ** year, 0)
            })

        return {
            "target_valuation": target_valuation,
            "cost_of_equity_pct": round(cost_of_equity * 100, 2),
            "projection_years": years,
            "terminal_growth_pct": round(terminal_growth * 100, 1),
            "terminal_multiple": round(terminal_multiple, 1),
            "terminal_fcf_required": round(terminal_fcf, 0),
            "year_1_fcf_required": round(year_1_fcf, 0),
            "fcf_trajectory": fcf_trajectory
        }
