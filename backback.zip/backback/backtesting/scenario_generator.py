"""
Scenario Generator

Pre-computes all scenario permutations for interactive HTML display.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from .config import STARTUPS, PEER_SCENARIOS, CUSTOM_TEMPLATES, DATA_DIR
from .data_fetcher import PeerDataFetcher
from .valuation_engine import ValuationEngine

logger = logging.getLogger(__name__)


class ScenarioGenerator:
    """Generate pre-computed scenarios for user customization."""

    def __init__(self):
        """Initialize the scenario generator."""
        self.fetcher = PeerDataFetcher()
        self.engine = ValuationEngine()

    def generate_all_scenarios(
        self,
        save_results: bool = True
    ) -> Dict:
        """
        Generate all scenario permutations for interactive display.

        For each startup, tests against each peer scenario.
        Total: 8 startups × 4 peer scenarios = 32 base scenarios.

        Args:
            save_results: Whether to save to JSON

        Returns:
            Dictionary with all pre-computed scenarios
        """
        scenarios = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "total_startups": len(STARTUPS),
                "peer_scenarios": list(PEER_SCENARIOS.keys()),
                "custom_templates": list(CUSTOM_TEMPLATES.keys())
            },
            "startup_scenarios": {},
            "custom_templates": {},
            "peer_scenarios_info": PEER_SCENARIOS
        }

        # Generate scenarios for each startup
        for startup_id, startup_data in STARTUPS.items():
            logger.info(f"Generating scenarios for {startup_data['name']}...")
            scenarios["startup_scenarios"][startup_id] = self._generate_startup_scenarios(
                startup_id, startup_data
            )

        # Generate custom template scenarios
        for template_id, template_data in CUSTOM_TEMPLATES.items():
            logger.info(f"Generating template scenarios for {template_data['name']}...")
            scenarios["custom_templates"][template_id] = self._generate_template_scenarios(
                template_id, template_data
            )

        if save_results:
            self._save_scenarios(scenarios)

        return scenarios

    def _generate_startup_scenarios(
        self,
        startup_id: str,
        startup: Dict
    ) -> Dict:
        """
        Generate all peer scenarios for a single startup.

        Args:
            startup_id: Startup identifier
            startup: Startup data

        Returns:
            Dictionary with results for each peer scenario
        """
        results = {
            "startup_info": {
                "id": startup_id,
                "name": startup.get("name"),
                "industry": startup.get("industry"),
                "revenue": startup.get("revenue_2025") or startup.get("arr_2025"),
                "valuation": startup.get("valuation"),
                "growth_rate": startup.get("growth_rate_pct"),
                "deal_type": startup.get("deal_type")
            },
            "default_peers": startup.get("peers", []),
            "scenarios": {}
        }

        # Test with default peers
        default_result = self._run_scenario(startup, startup.get("peers", []))
        results["scenarios"]["default"] = {
            "name": "Default Peers",
            "description": f"Original peer group: {', '.join(startup.get('peers', []))}",
            "peers": startup.get("peers", []),
            **default_result
        }

        # Test with each alternative peer scenario
        for scenario_id, scenario_config in PEER_SCENARIOS.items():
            scenario_result = self._run_scenario(startup, scenario_config["peers"])
            results["scenarios"][scenario_id] = {
                "name": scenario_config["name"],
                "description": scenario_config["description"],
                "peers": scenario_config["peers"],
                **scenario_result
            }

        return results

    def _generate_template_scenarios(
        self,
        template_id: str,
        template: Dict
    ) -> Dict:
        """
        Generate scenarios for a custom template.

        Args:
            template_id: Template identifier
            template: Template configuration

        Returns:
            Dictionary with template scenarios
        """
        # Create a startup-like dict from template
        startup = {
            "name": template.get("name"),
            "revenue_2025": template.get("revenue_2025") or template.get("revenue"),
            "arr_2025": template.get("arr_2025"),
            "valuation": template.get("valuation"),
            "growth_rate_pct": template.get("growth_rate_pct"),
            "de_ratio_pct": template.get("de_ratio_pct", 0),
            "deal_type": template.get("deal_type", "vc_growth"),
            "peers": template.get("peers", [])
        }

        results = {
            "template_info": {
                "id": template_id,
                "name": template.get("name"),
                "description": template.get("description"),
                "revenue": startup.get("revenue_2025") or startup.get("arr_2025"),
                "valuation": startup.get("valuation"),
                "growth_rate": startup.get("growth_rate_pct")
            },
            "default_peers": template.get("peers", []),
            "scenarios": {}
        }

        # Test with default peers
        default_result = self._run_scenario(startup, template.get("peers", []))
        results["scenarios"]["default"] = {
            "name": "Default Peers",
            "description": f"Template peer group: {', '.join(template.get('peers', []))}",
            "peers": template.get("peers", []),
            **default_result
        }

        # Test with each alternative peer scenario
        for scenario_id, scenario_config in PEER_SCENARIOS.items():
            scenario_result = self._run_scenario(startup, scenario_config["peers"])
            results["scenarios"][scenario_id] = {
                "name": scenario_config["name"],
                "description": scenario_config["description"],
                "peers": scenario_config["peers"],
                **scenario_result
            }

        return results

    def _run_scenario(
        self,
        startup: Dict,
        peers: List[str]
    ) -> Dict:
        """
        Run valuation for a single scenario.

        Args:
            startup: Startup data
            peers: List of peer tickers

        Returns:
            Valuation results
        """
        try:
            # Fetch peer data
            peers_df = self.fetcher.fetch_peer_group(peers, use_cache=True)
            peer_stats = self.fetcher.get_peer_statistics(peers_df)

            # Run both approaches
            approach_1 = self.engine.approach_1_trading_multiples(startup, peer_stats)
            approach_2 = self.engine.approach_2_bottom_up_beta(startup, peer_stats)

            # Format for display
            return {
                "peer_stats": {
                    "count": peer_stats.get("count", 0),
                    "median_ev_revenue": peer_stats.get("median_ev_revenue", 0),
                    "median_unlevered_beta": peer_stats.get("median_unlevered_beta", 0)
                },
                "approach_1": {
                    "implied_valuation": approach_1.get("implied_valuation", 0),
                    "implied_valuation_display": self._format_currency(approach_1.get("implied_valuation", 0)),
                    "gap": approach_1.get("gap", 0),
                    "gap_display": f"{approach_1.get('gap', 0):.1f}x",
                    "peer_multiple": approach_1.get("peer_median_multiple", 0),
                    "implied_multiple": approach_1.get("implied_market_multiple", 0)
                },
                "approach_2": {
                    "cost_of_equity_pct": approach_2.get("cost_of_equity_pct", 0),
                    "coe_display": f"{approach_2.get('cost_of_equity_pct', 0):.1f}%",
                    "relevered_beta": approach_2.get("relevered_beta", 0),
                    "size_premium_pct": approach_2.get("size_premium_pct", 0)
                },
                "success": True
            }

        except Exception as e:
            logger.error(f"Error running scenario: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    def _format_currency(self, value: float) -> str:
        """Format currency value for display."""
        if value >= 1e12:
            return f"${value/1e12:.1f}T"
        elif value >= 1e9:
            return f"${value/1e9:.1f}B"
        elif value >= 1e6:
            return f"${value/1e6:.1f}M"
        else:
            return f"${value:,.0f}"

    def _save_scenarios(self, scenarios: Dict) -> Path:
        """Save scenarios to JSON file."""
        output_path = DATA_DIR / "custom_scenarios.json"
        with open(output_path, 'w') as f:
            json.dump(scenarios, f, indent=2, default=str)
        logger.info(f"Scenarios saved to {output_path}")
        return output_path

    def generate_scenario_summary(self) -> Dict:
        """
        Generate a summary of scenario variations.

        Shows how much valuations vary across different peer selections.
        """
        all_scenarios = self.generate_all_scenarios(save_results=False)

        summary = {
            "by_startup": {},
            "overall_sensitivity": {}
        }

        for startup_id, startup_data in all_scenarios["startup_scenarios"].items():
            gaps = []
            coes = []

            for scenario_id, scenario in startup_data["scenarios"].items():
                if scenario.get("success", False):
                    gaps.append(scenario["approach_1"]["gap"])
                    coes.append(scenario["approach_2"]["cost_of_equity_pct"])

            if gaps:
                summary["by_startup"][startup_id] = {
                    "name": startup_data["startup_info"]["name"],
                    "gap_range": f"{min(gaps):.1f}x - {max(gaps):.1f}x",
                    "gap_spread": round(max(gaps) - min(gaps), 2),
                    "coe_range": f"{min(coes):.1f}% - {max(coes):.1f}%",
                    "coe_spread": round(max(coes) - min(coes), 2)
                }

        return summary


def generate_scenarios_for_html():
    """
    Generate all scenarios and return formatted for HTML embedding.

    This is the main entry point for the HTML generator.
    """
    generator = ScenarioGenerator()
    return generator.generate_all_scenarios(save_results=True)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    generate_scenarios_for_html()
