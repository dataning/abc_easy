#!/usr/bin/env python3
"""
Run Valuation Backtesting

CLI entry point for running backtest analysis and generating HTML output.

Usage:
    python run_backtest.py                    # Full backtest + HTML generation
    python run_backtest.py --quick            # Quick test (Groq only)
    python run_backtest.py --no-fetch         # Use cached data only
    python run_backtest.py --sensitivity      # Include sensitivity analysis
"""

import argparse
import logging
import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from backtesting.config import STARTUPS, DATA_DIR
from backtesting.backtest_runner import BacktestRunner
from backtesting.scenario_generator import ScenarioGenerator
from backtesting.html_generator import HTMLGenerator


def setup_logging(verbose: bool = False):
    """Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )


def run_full_backtest(use_cache: bool = True, include_sensitivity: bool = False):
    """Run full backtesting pipeline."""
    logger = logging.getLogger(__name__)

    print("\n" + "="*60)
    print("VALUATION BACKTESTING: Trading Multiples vs. Bottom-Up Beta")
    print("="*60 + "\n")

    # Step 1: Run backtesting
    print("[1/3] Running backtesting on all startups...")
    runner = BacktestRunner(use_cache=use_cache)
    backtest_results = runner.run_full_backtest()

    # Print summary
    display = backtest_results.get("display_data", {})
    summary = display.get("summary_stats", {})
    print(f"\n  Startups analyzed: {summary.get('total_startups', 0)}")
    print(f"  Average Gap: {summary.get('avg_gap', 0):.1f}x")
    print(f"  Average CoE: {summary.get('avg_coe', 0):.1f}%")

    # Step 2: Generate scenarios
    print("\n[2/3] Generating pre-computed scenarios...")
    scenario_gen = ScenarioGenerator()
    scenarios = scenario_gen.generate_all_scenarios(save_results=True)
    print(f"  Generated scenarios for {len(scenarios.get('startup_scenarios', {}))} startups")

    # Optional: Sensitivity analysis
    if include_sensitivity:
        print("\n[2b] Running sensitivity analysis...")
        sensitivity = runner.run_sensitivity_analysis()
        backtest_results["sensitivity_analysis"] = sensitivity

    # Step 3: Generate HTML
    print("\n[3/3] Generating HTML output...")
    html_gen = HTMLGenerator()
    output_path = html_gen.generate_backtest_page(backtest_results, scenarios)
    print(f"  Generated: {output_path}")

    print("\n" + "="*60)
    print("BACKTESTING COMPLETE")
    print("="*60)
    print(f"\nOutput files:")
    print(f"  - {output_path}")
    print(f"  - {DATA_DIR / 'backtest_results.json'}")
    print(f"  - {DATA_DIR / 'custom_scenarios.json'}")

    print("\n[Results Summary]")
    comparison = backtest_results.get("approach_comparison", {})
    winner = comparison.get("winner", "unknown")
    print(f"  Winner: {'Bottom-Up Beta' if winner == 'bottom_up_beta' else 'Trading Multiples'}")
    print(f"  Reason: {comparison.get('winner_reason', 'N/A')}")

    return output_path


def run_quick_test():
    """Quick test with single startup."""
    logger = logging.getLogger(__name__)

    print("\n[Quick Test] Running backtest on Groq only...\n")

    runner = BacktestRunner(use_cache=True)
    result = runner.backtest_single("groq", STARTUPS["groq"])

    print(f"Startup: {result['startup_data']['name']}")
    print(f"Actual Valuation: ${result['startup_data']['valuation'] / 1e9:.1f}B")
    print(f"\nApproach 1 (Trading Multiples):")
    print(f"  Implied Valuation: ${result['approach_1']['implied_valuation'] / 1e9:.1f}B")
    print(f"  Gap: {result['approach_1']['gap']:.1f}x")
    print(f"  Peer Multiple: {result['approach_1']['peer_median_multiple']:.1f}x")

    print(f"\nApproach 2 (Bottom-Up Beta):")
    print(f"  Cost of Equity: {result['approach_2']['cost_of_equity_pct']:.1f}%")
    print(f"  Relevered Beta: {result['approach_2']['relevered_beta']:.2f}")
    print(f"  Size Premium: {result['approach_2']['size_premium_pct']:.1f}%")

    print(f"\nPeers used: {', '.join(result['startup_data']['peers'])}")

    return result


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Run valuation backtesting analysis"
    )
    parser.add_argument(
        "--quick", "-q",
        action="store_true",
        help="Quick test with single startup (Groq)"
    )
    parser.add_argument(
        "--no-fetch",
        action="store_true",
        help="Use cached data only, don't fetch from Yahoo Finance"
    )
    parser.add_argument(
        "--sensitivity", "-s",
        action="store_true",
        help="Include sensitivity analysis (tests multiple peer scenarios)"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )

    args = parser.parse_args()
    setup_logging(args.verbose)

    try:
        if args.quick:
            run_quick_test()
        else:
            run_full_backtest(
                use_cache=not args.no_fetch,
                include_sensitivity=args.sensitivity
            )
    except KeyboardInterrupt:
        print("\n\nAborted by user.")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Error: {e}")
        if args.verbose:
            raise
        sys.exit(1)


if __name__ == "__main__":
    main()
